var html2mdWorker = (() => {
  var __create = Object.create;
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __getProtoOf = Object.getPrototypeOf;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __commonJS = (cb, mod) => function __require() {
    try {
      return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
    } catch (e) {
      throw mod = 0, e;
    }
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
    // If the importer is in node compatibility mode or this is not an ESM
    // file that has been converted to a CommonJS file using a Babel-
    // compatible transform (i.e. "__esModule" has not been set), then set
    // "default" to the CommonJS "module.exports" for node compatibility.
    isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
    mod
  ));

  // node_modules/@mozilla/readability/Readability.js
  var require_Readability = __commonJS({
    "node_modules/@mozilla/readability/Readability.js"(exports, module) {
      function Readability2(doc, options) {
        if (options && options.documentElement) {
          doc = options;
          options = arguments[2];
        } else if (!doc || !doc.documentElement) {
          throw new Error(
            "First argument to Readability constructor should be a document object."
          );
        }
        options = options || {};
        this._doc = doc;
        this._docJSDOMParser = this._doc.firstChild.__JSDOMParser__;
        this._articleTitle = null;
        this._articleByline = null;
        this._articleDir = null;
        this._articleSiteName = null;
        this._attempts = [];
        this._metadata = {};
        this._debug = !!options.debug;
        this._maxElemsToParse = options.maxElemsToParse || this.DEFAULT_MAX_ELEMS_TO_PARSE;
        this._nbTopCandidates = options.nbTopCandidates || this.DEFAULT_N_TOP_CANDIDATES;
        this._charThreshold = options.charThreshold || this.DEFAULT_CHAR_THRESHOLD;
        this._classesToPreserve = this.CLASSES_TO_PRESERVE.concat(
          options.classesToPreserve || []
        );
        this._keepClasses = !!options.keepClasses;
        this._serializer = options.serializer || function(el) {
          return el.innerHTML;
        };
        this._disableJSONLD = !!options.disableJSONLD;
        this._allowedVideoRegex = options.allowedVideoRegex || this.REGEXPS.videos;
        this._linkDensityModifier = options.linkDensityModifier || 0;
        this._flags = this.FLAG_STRIP_UNLIKELYS | this.FLAG_WEIGHT_CLASSES | this.FLAG_CLEAN_CONDITIONALLY;
        if (this._debug) {
          let logNode = function(node) {
            if (node.nodeType == node.TEXT_NODE) {
              return `${node.nodeName} ("${node.textContent}")`;
            }
            let attrPairs = Array.from(node.attributes || [], function(attr) {
              return `${attr.name}="${attr.value}"`;
            }).join(" ");
            return `<${node.localName} ${attrPairs}>`;
          };
          this.log = function() {
            if (typeof console !== "undefined") {
              let args = Array.from(arguments, (arg) => {
                if (arg && arg.nodeType == this.ELEMENT_NODE) {
                  return logNode(arg);
                }
                return arg;
              });
              args.unshift("Reader: (Readability)");
              console.log(...args);
            } else if (typeof dump !== "undefined") {
              var msg = Array.prototype.map.call(arguments, function(x) {
                return x && x.nodeName ? logNode(x) : x;
              }).join(" ");
              dump("Reader: (Readability) " + msg + "\n");
            }
          };
        } else {
          this.log = function() {
          };
        }
      }
      Readability2.prototype = {
        FLAG_STRIP_UNLIKELYS: 1,
        FLAG_WEIGHT_CLASSES: 2,
        FLAG_CLEAN_CONDITIONALLY: 4,
        // https://developer.mozilla.org/en-US/docs/Web/API/Node/nodeType
        ELEMENT_NODE: 1,
        TEXT_NODE: 3,
        // Max number of nodes supported by this parser. Default: 0 (no limit)
        DEFAULT_MAX_ELEMS_TO_PARSE: 0,
        // The number of top candidates to consider when analysing how
        // tight the competition is among candidates.
        DEFAULT_N_TOP_CANDIDATES: 5,
        // Element tags to score by default.
        DEFAULT_TAGS_TO_SCORE: "section,h2,h3,h4,h5,h6,p,td,pre".toUpperCase().split(","),
        // The default number of chars an article must have in order to return a result
        DEFAULT_CHAR_THRESHOLD: 500,
        // All of the regular expressions in use within readability.
        // Defined up here so we don't instantiate them repeatedly in loops.
        REGEXPS: {
          // NOTE: These two regular expressions are duplicated in
          // Readability-readerable.js. Please keep both copies in sync.
          unlikelyCandidates: /-ad-|ai2html|banner|breadcrumbs|combx|comment|community|cover-wrap|disqus|extra|footer|gdpr|header|legends|menu|related|remark|replies|rss|shoutbox|sidebar|skyscraper|social|sponsor|supplemental|ad-break|agegate|pagination|pager|popup|yom-remote/i,
          okMaybeItsACandidate: /and|article|body|column|content|main|shadow/i,
          positive: /article|body|content|entry|hentry|h-entry|main|page|pagination|post|text|blog|story/i,
          negative: /-ad-|hidden|^hid$| hid$| hid |^hid |banner|combx|comment|com-|contact|footer|gdpr|masthead|media|meta|outbrain|promo|related|scroll|share|shoutbox|sidebar|skyscraper|sponsor|shopping|tags|widget/i,
          extraneous: /print|archive|comment|discuss|e[\-]?mail|share|reply|all|login|sign|single|utility/i,
          byline: /byline|author|dateline|writtenby|p-author/i,
          replaceFonts: /<(\/?)font[^>]*>/gi,
          normalize: /\s{2,}/g,
          videos: /\/\/(www\.)?((dailymotion|youtube|youtube-nocookie|player\.vimeo|v\.qq)\.com|(archive|upload\.wikimedia)\.org|player\.twitch\.tv)/i,
          shareElements: /(\b|_)(share|sharedaddy)(\b|_)/i,
          nextLink: /(next|weiter|continue|>([^\|]|$)|»([^\|]|$))/i,
          prevLink: /(prev|earl|old|new|<|«)/i,
          tokenize: /\W+/g,
          whitespace: /^\s*$/,
          hasContent: /\S$/,
          hashUrl: /^#.+/,
          srcsetUrl: /(\S+)(\s+[\d.]+[xw])?(\s*(?:,|$))/g,
          b64DataUrl: /^data:\s*([^\s;,]+)\s*;\s*base64\s*,/i,
          // Commas as used in Latin, Sindhi, Chinese and various other scripts.
          // see: https://en.wikipedia.org/wiki/Comma#Comma_variants
          commas: /\u002C|\u060C|\uFE50|\uFE10|\uFE11|\u2E41|\u2E34|\u2E32|\uFF0C/g,
          // See: https://schema.org/Article
          jsonLdArticleTypes: /^Article|AdvertiserContentArticle|NewsArticle|AnalysisNewsArticle|AskPublicNewsArticle|BackgroundNewsArticle|OpinionNewsArticle|ReportageNewsArticle|ReviewNewsArticle|Report|SatiricalArticle|ScholarlyArticle|MedicalScholarlyArticle|SocialMediaPosting|BlogPosting|LiveBlogPosting|DiscussionForumPosting|TechArticle|APIReference$/,
          // used to see if a node's content matches words commonly used for ad blocks or loading indicators
          adWords: /^(ad(vertising|vertisement)?|pub(licité)?|werb(ung)?|广告|Реклама|Anuncio)$/iu,
          loadingWords: /^((loading|正在加载|Загрузка|chargement|cargando)(…|\.\.\.)?)$/iu
        },
        UNLIKELY_ROLES: [
          "menu",
          "menubar",
          "complementary",
          "navigation",
          "alert",
          "alertdialog",
          "dialog"
        ],
        DIV_TO_P_ELEMS: /* @__PURE__ */ new Set([
          "BLOCKQUOTE",
          "DL",
          "DIV",
          "IMG",
          "OL",
          "P",
          "PRE",
          "TABLE",
          "UL"
        ]),
        ALTER_TO_DIV_EXCEPTIONS: ["DIV", "ARTICLE", "SECTION", "P", "OL", "UL"],
        PRESENTATIONAL_ATTRIBUTES: [
          "align",
          "background",
          "bgcolor",
          "border",
          "cellpadding",
          "cellspacing",
          "frame",
          "hspace",
          "rules",
          "style",
          "valign",
          "vspace"
        ],
        DEPRECATED_SIZE_ATTRIBUTE_ELEMS: ["TABLE", "TH", "TD", "HR", "PRE"],
        // The commented out elements qualify as phrasing content but tend to be
        // removed by readability when put into paragraphs, so we ignore them here.
        PHRASING_ELEMS: [
          // "CANVAS", "IFRAME", "SVG", "VIDEO",
          "ABBR",
          "AUDIO",
          "B",
          "BDO",
          "BR",
          "BUTTON",
          "CITE",
          "CODE",
          "DATA",
          "DATALIST",
          "DFN",
          "EM",
          "EMBED",
          "I",
          "IMG",
          "INPUT",
          "KBD",
          "LABEL",
          "MARK",
          "MATH",
          "METER",
          "NOSCRIPT",
          "OBJECT",
          "OUTPUT",
          "PROGRESS",
          "Q",
          "RUBY",
          "SAMP",
          "SCRIPT",
          "SELECT",
          "SMALL",
          "SPAN",
          "STRONG",
          "SUB",
          "SUP",
          "TEXTAREA",
          "TIME",
          "VAR",
          "WBR"
        ],
        // These are the classes that readability sets itself.
        CLASSES_TO_PRESERVE: ["page"],
        // These are the list of HTML entities that need to be escaped.
        HTML_ESCAPE_MAP: {
          lt: "<",
          gt: ">",
          amp: "&",
          quot: '"',
          apos: "'"
        },
        /**
         * Run any post-process modifications to article content as necessary.
         *
         * @param Element
         * @return void
         **/
        _postProcessContent(articleContent) {
          this._fixRelativeUris(articleContent);
          this._simplifyNestedElements(articleContent);
          if (!this._keepClasses) {
            this._cleanClasses(articleContent);
          }
        },
        /**
         * Iterates over a NodeList, calls `filterFn` for each node and removes node
         * if function returned `true`.
         *
         * If function is not passed, removes all the nodes in node list.
         *
         * @param NodeList nodeList The nodes to operate on
         * @param Function filterFn the function to use as a filter
         * @return void
         */
        _removeNodes(nodeList, filterFn) {
          if (this._docJSDOMParser && nodeList._isLiveNodeList) {
            throw new Error("Do not pass live node lists to _removeNodes");
          }
          for (var i = nodeList.length - 1; i >= 0; i--) {
            var node = nodeList[i];
            var parentNode = node.parentNode;
            if (parentNode) {
              if (!filterFn || filterFn.call(this, node, i, nodeList)) {
                parentNode.removeChild(node);
              }
            }
          }
        },
        /**
         * Iterates over a NodeList, and calls _setNodeTag for each node.
         *
         * @param NodeList nodeList The nodes to operate on
         * @param String newTagName the new tag name to use
         * @return void
         */
        _replaceNodeTags(nodeList, newTagName) {
          if (this._docJSDOMParser && nodeList._isLiveNodeList) {
            throw new Error("Do not pass live node lists to _replaceNodeTags");
          }
          for (const node of nodeList) {
            this._setNodeTag(node, newTagName);
          }
        },
        /**
         * Iterate over a NodeList, which doesn't natively fully implement the Array
         * interface.
         *
         * For convenience, the current object context is applied to the provided
         * iterate function.
         *
         * @param  NodeList nodeList The NodeList.
         * @param  Function fn       The iterate function.
         * @return void
         */
        _forEachNode(nodeList, fn) {
          Array.prototype.forEach.call(nodeList, fn, this);
        },
        /**
         * Iterate over a NodeList, and return the first node that passes
         * the supplied test function
         *
         * For convenience, the current object context is applied to the provided
         * test function.
         *
         * @param  NodeList nodeList The NodeList.
         * @param  Function fn       The test function.
         * @return void
         */
        _findNode(nodeList, fn) {
          return Array.prototype.find.call(nodeList, fn, this);
        },
        /**
         * Iterate over a NodeList, return true if any of the provided iterate
         * function calls returns true, false otherwise.
         *
         * For convenience, the current object context is applied to the
         * provided iterate function.
         *
         * @param  NodeList nodeList The NodeList.
         * @param  Function fn       The iterate function.
         * @return Boolean
         */
        _someNode(nodeList, fn) {
          return Array.prototype.some.call(nodeList, fn, this);
        },
        /**
         * Iterate over a NodeList, return true if all of the provided iterate
         * function calls return true, false otherwise.
         *
         * For convenience, the current object context is applied to the
         * provided iterate function.
         *
         * @param  NodeList nodeList The NodeList.
         * @param  Function fn       The iterate function.
         * @return Boolean
         */
        _everyNode(nodeList, fn) {
          return Array.prototype.every.call(nodeList, fn, this);
        },
        _getAllNodesWithTag(node, tagNames) {
          if (node.querySelectorAll) {
            return node.querySelectorAll(tagNames.join(","));
          }
          return [].concat.apply(
            [],
            tagNames.map(function(tag) {
              var collection = node.getElementsByTagName(tag);
              return Array.isArray(collection) ? collection : Array.from(collection);
            })
          );
        },
        /**
         * Removes the class="" attribute from every element in the given
         * subtree, except those that match CLASSES_TO_PRESERVE and
         * the classesToPreserve array from the options object.
         *
         * @param Element
         * @return void
         */
        _cleanClasses(node) {
          var classesToPreserve = this._classesToPreserve;
          var className = (node.getAttribute("class") || "").split(/\s+/).filter((cls) => classesToPreserve.includes(cls)).join(" ");
          if (className) {
            node.setAttribute("class", className);
          } else {
            node.removeAttribute("class");
          }
          for (node = node.firstElementChild; node; node = node.nextElementSibling) {
            this._cleanClasses(node);
          }
        },
        /**
         * Tests whether a string is a URL or not.
         *
         * @param {string} str The string to test
         * @return {boolean} true if str is a URL, false if not
         */
        _isUrl(str) {
          try {
            new URL(str);
            return true;
          } catch {
            return false;
          }
        },
        /**
         * Converts each <a> and <img> uri in the given element to an absolute URI,
         * ignoring #ref URIs.
         *
         * @param Element
         * @return void
         */
        _fixRelativeUris(articleContent) {
          var baseURI = this._doc.baseURI;
          var documentURI = this._doc.documentURI;
          function toAbsoluteURI(uri) {
            if (baseURI == documentURI && uri.charAt(0) == "#") {
              return uri;
            }
            try {
              return new URL(uri, baseURI).href;
            } catch (ex) {
            }
            return uri;
          }
          var links = this._getAllNodesWithTag(articleContent, ["a"]);
          this._forEachNode(links, function(link) {
            var href = link.getAttribute("href");
            if (href) {
              if (href.indexOf("javascript:") === 0) {
                if (link.childNodes.length === 1 && link.childNodes[0].nodeType === this.TEXT_NODE) {
                  var text = this._doc.createTextNode(link.textContent);
                  link.parentNode.replaceChild(text, link);
                } else {
                  var container = this._doc.createElement("span");
                  while (link.firstChild) {
                    container.appendChild(link.firstChild);
                  }
                  link.parentNode.replaceChild(container, link);
                }
              } else {
                link.setAttribute("href", toAbsoluteURI(href));
              }
            }
          });
          var medias = this._getAllNodesWithTag(articleContent, [
            "img",
            "picture",
            "figure",
            "video",
            "audio",
            "source"
          ]);
          this._forEachNode(medias, function(media) {
            var src = media.getAttribute("src");
            var poster = media.getAttribute("poster");
            var srcset = media.getAttribute("srcset");
            if (src) {
              media.setAttribute("src", toAbsoluteURI(src));
            }
            if (poster) {
              media.setAttribute("poster", toAbsoluteURI(poster));
            }
            if (srcset) {
              var newSrcset = srcset.replace(
                this.REGEXPS.srcsetUrl,
                function(_, p1, p2, p3) {
                  return toAbsoluteURI(p1) + (p2 || "") + p3;
                }
              );
              media.setAttribute("srcset", newSrcset);
            }
          });
        },
        _simplifyNestedElements(articleContent) {
          var node = articleContent;
          while (node) {
            if (node.parentNode && ["DIV", "SECTION"].includes(node.tagName) && !(node.id && node.id.startsWith("readability"))) {
              if (this._isElementWithoutContent(node)) {
                node = this._removeAndGetNext(node);
                continue;
              } else if (this._hasSingleTagInsideElement(node, "DIV") || this._hasSingleTagInsideElement(node, "SECTION")) {
                var child = node.children[0];
                for (var i = 0; i < node.attributes.length; i++) {
                  child.setAttributeNode(node.attributes[i].cloneNode());
                }
                node.parentNode.replaceChild(child, node);
                node = child;
                continue;
              }
            }
            node = this._getNextNode(node);
          }
        },
        /**
         * Get the article title as an H1.
         *
         * @return string
         **/
        _getArticleTitle() {
          var doc = this._doc;
          var curTitle = "";
          var origTitle = "";
          try {
            curTitle = origTitle = doc.title.trim();
            if (typeof curTitle !== "string") {
              curTitle = origTitle = this._getInnerText(
                doc.getElementsByTagName("title")[0]
              );
            }
          } catch (e) {
          }
          var titleHadHierarchicalSeparators = false;
          function wordCount(str) {
            return str.split(/\s+/).length;
          }
          if (/ [\|\-\\\/>»] /.test(curTitle)) {
            titleHadHierarchicalSeparators = / [\\\/>»] /.test(curTitle);
            let allSeparators = Array.from(origTitle.matchAll(/ [\|\-\\\/>»] /gi));
            curTitle = origTitle.substring(0, allSeparators.pop().index);
            if (wordCount(curTitle) < 3) {
              curTitle = origTitle.replace(/^[^\|\-\\\/>»]*[\|\-\\\/>»]/gi, "");
            }
          } else if (curTitle.includes(": ")) {
            var headings = this._getAllNodesWithTag(doc, ["h1", "h2"]);
            var trimmedTitle = curTitle.trim();
            var match = this._someNode(headings, function(heading) {
              return heading.textContent.trim() === trimmedTitle;
            });
            if (!match) {
              curTitle = origTitle.substring(origTitle.lastIndexOf(":") + 1);
              if (wordCount(curTitle) < 3) {
                curTitle = origTitle.substring(origTitle.indexOf(":") + 1);
              } else if (wordCount(origTitle.substr(0, origTitle.indexOf(":"))) > 5) {
                curTitle = origTitle;
              }
            }
          } else if (curTitle.length > 150 || curTitle.length < 15) {
            var hOnes = doc.getElementsByTagName("h1");
            if (hOnes.length === 1) {
              curTitle = this._getInnerText(hOnes[0]);
            }
          }
          curTitle = curTitle.trim().replace(this.REGEXPS.normalize, " ");
          var curTitleWordCount = wordCount(curTitle);
          if (curTitleWordCount <= 4 && (!titleHadHierarchicalSeparators || curTitleWordCount != wordCount(origTitle.replace(/[\|\-\\\/>»]+/g, "")) - 1)) {
            curTitle = origTitle;
          }
          return curTitle;
        },
        /**
         * Prepare the HTML document for readability to scrape it.
         * This includes things like stripping javascript, CSS, and handling terrible markup.
         *
         * @return void
         **/
        _prepDocument() {
          var doc = this._doc;
          this._removeNodes(this._getAllNodesWithTag(doc, ["style"]));
          if (doc.body) {
            this._replaceBrs(doc.body);
          }
          this._replaceNodeTags(this._getAllNodesWithTag(doc, ["font"]), "SPAN");
        },
        /**
         * Finds the next node, starting from the given node, and ignoring
         * whitespace in between. If the given node is an element, the same node is
         * returned.
         */
        _nextNode(node) {
          var next2 = node;
          while (next2 && next2.nodeType != this.ELEMENT_NODE && this.REGEXPS.whitespace.test(next2.textContent)) {
            next2 = next2.nextSibling;
          }
          return next2;
        },
        /**
         * Replaces 2 or more successive <br> elements with a single <p>.
         * Whitespace between <br> elements are ignored. For example:
         *   <div>foo<br>bar<br> <br><br>abc</div>
         * will become:
         *   <div>foo<br>bar<p>abc</p></div>
         */
        _replaceBrs(elem) {
          this._forEachNode(this._getAllNodesWithTag(elem, ["br"]), function(br) {
            var next2 = br.nextSibling;
            var replaced = false;
            while ((next2 = this._nextNode(next2)) && next2.tagName == "BR") {
              replaced = true;
              var brSibling = next2.nextSibling;
              next2.remove();
              next2 = brSibling;
            }
            if (replaced) {
              var p = this._doc.createElement("p");
              br.parentNode.replaceChild(p, br);
              next2 = p.nextSibling;
              while (next2) {
                if (next2.tagName == "BR") {
                  var nextElem = this._nextNode(next2.nextSibling);
                  if (nextElem && nextElem.tagName == "BR") {
                    break;
                  }
                }
                if (!this._isPhrasingContent(next2)) {
                  break;
                }
                var sibling = next2.nextSibling;
                p.appendChild(next2);
                next2 = sibling;
              }
              while (p.lastChild && this._isWhitespace(p.lastChild)) {
                p.lastChild.remove();
              }
              if (p.parentNode.tagName === "P") {
                this._setNodeTag(p.parentNode, "DIV");
              }
            }
          });
        },
        _setNodeTag(node, tag) {
          this.log("_setNodeTag", node, tag);
          if (this._docJSDOMParser) {
            node.localName = tag.toLowerCase();
            node.tagName = tag.toUpperCase();
            return node;
          }
          var replacement = node.ownerDocument.createElement(tag);
          while (node.firstChild) {
            replacement.appendChild(node.firstChild);
          }
          node.parentNode.replaceChild(replacement, node);
          if (node.readability) {
            replacement.readability = node.readability;
          }
          for (var i = 0; i < node.attributes.length; i++) {
            replacement.setAttributeNode(node.attributes[i].cloneNode());
          }
          return replacement;
        },
        /**
         * Prepare the article node for display. Clean out any inline styles,
         * iframes, forms, strip extraneous <p> tags, etc.
         *
         * @param Element
         * @return void
         **/
        _prepArticle(articleContent) {
          this._cleanStyles(articleContent);
          this._markDataTables(articleContent);
          this._fixLazyImages(articleContent);
          this._cleanConditionally(articleContent, "form");
          this._cleanConditionally(articleContent, "fieldset");
          this._clean(articleContent, "object");
          this._clean(articleContent, "embed");
          this._clean(articleContent, "footer");
          this._clean(articleContent, "link");
          this._clean(articleContent, "aside");
          var shareElementThreshold = this.DEFAULT_CHAR_THRESHOLD;
          this._forEachNode(articleContent.children, function(topCandidate) {
            this._cleanMatchedNodes(topCandidate, function(node, matchString) {
              return this.REGEXPS.shareElements.test(matchString) && node.textContent.length < shareElementThreshold;
            });
          });
          this._clean(articleContent, "iframe");
          this._clean(articleContent, "input");
          this._clean(articleContent, "textarea");
          this._clean(articleContent, "select");
          this._clean(articleContent, "button");
          this._cleanHeaders(articleContent);
          this._cleanConditionally(articleContent, "table");
          this._cleanConditionally(articleContent, "ul");
          this._cleanConditionally(articleContent, "div");
          this._replaceNodeTags(
            this._getAllNodesWithTag(articleContent, ["h1"]),
            "h2"
          );
          this._removeNodes(
            this._getAllNodesWithTag(articleContent, ["p"]),
            function(paragraph) {
              var contentElementCount = this._getAllNodesWithTag(paragraph, [
                "img",
                "embed",
                "object",
                "iframe"
              ]).length;
              return contentElementCount === 0 && !this._getInnerText(paragraph, false);
            }
          );
          this._forEachNode(
            this._getAllNodesWithTag(articleContent, ["br"]),
            function(br) {
              var next2 = this._nextNode(br.nextSibling);
              if (next2 && next2.tagName == "P") {
                br.remove();
              }
            }
          );
          this._forEachNode(
            this._getAllNodesWithTag(articleContent, ["table"]),
            function(table) {
              var tbody = this._hasSingleTagInsideElement(table, "TBODY") ? table.firstElementChild : table;
              if (this._hasSingleTagInsideElement(tbody, "TR")) {
                var row = tbody.firstElementChild;
                if (this._hasSingleTagInsideElement(row, "TD")) {
                  var cell2 = row.firstElementChild;
                  cell2 = this._setNodeTag(
                    cell2,
                    this._everyNode(cell2.childNodes, this._isPhrasingContent) ? "P" : "DIV"
                  );
                  table.parentNode.replaceChild(cell2, table);
                }
              }
            }
          );
        },
        /**
         * Initialize a node with the readability object. Also checks the
         * className/id for special names to add to its score.
         *
         * @param Element
         * @return void
         **/
        _initializeNode(node) {
          node.readability = { contentScore: 0 };
          switch (node.tagName) {
            case "DIV":
              node.readability.contentScore += 5;
              break;
            case "PRE":
            case "TD":
            case "BLOCKQUOTE":
              node.readability.contentScore += 3;
              break;
            case "ADDRESS":
            case "OL":
            case "UL":
            case "DL":
            case "DD":
            case "DT":
            case "LI":
            case "FORM":
              node.readability.contentScore -= 3;
              break;
            case "H1":
            case "H2":
            case "H3":
            case "H4":
            case "H5":
            case "H6":
            case "TH":
              node.readability.contentScore -= 5;
              break;
          }
          node.readability.contentScore += this._getClassWeight(node);
        },
        _removeAndGetNext(node) {
          var nextNode = this._getNextNode(node, true);
          node.remove();
          return nextNode;
        },
        /**
         * Traverse the DOM from node to node, starting at the node passed in.
         * Pass true for the second parameter to indicate this node itself
         * (and its kids) are going away, and we want the next node over.
         *
         * Calling this in a loop will traverse the DOM depth-first.
         *
         * @param {Element} node
         * @param {boolean} ignoreSelfAndKids
         * @return {Element}
         */
        _getNextNode(node, ignoreSelfAndKids) {
          if (!ignoreSelfAndKids && node.firstElementChild) {
            return node.firstElementChild;
          }
          if (node.nextElementSibling) {
            return node.nextElementSibling;
          }
          do {
            node = node.parentNode;
          } while (node && !node.nextElementSibling);
          return node && node.nextElementSibling;
        },
        // compares second text to first one
        // 1 = same text, 0 = completely different text
        // works the way that it splits both texts into words and then finds words that are unique in second text
        // the result is given by the lower length of unique parts
        _textSimilarity(textA, textB) {
          var tokensA = textA.toLowerCase().split(this.REGEXPS.tokenize).filter(Boolean);
          var tokensB = textB.toLowerCase().split(this.REGEXPS.tokenize).filter(Boolean);
          if (!tokensA.length || !tokensB.length) {
            return 0;
          }
          var uniqTokensB = tokensB.filter((token) => !tokensA.includes(token));
          var distanceB = uniqTokensB.join(" ").length / tokensB.join(" ").length;
          return 1 - distanceB;
        },
        /**
         * Checks whether an element node contains a valid byline
         *
         * @param node {Element}
         * @param matchString {string}
         * @return boolean
         */
        _isValidByline(node, matchString) {
          var rel = node.getAttribute("rel");
          var itemprop = node.getAttribute("itemprop");
          var bylineLength = node.textContent.trim().length;
          return (rel === "author" || itemprop && itemprop.includes("author") || this.REGEXPS.byline.test(matchString)) && !!bylineLength && bylineLength < 100;
        },
        _getNodeAncestors(node, maxDepth) {
          maxDepth = maxDepth || 0;
          var i = 0, ancestors = [];
          while (node.parentNode) {
            ancestors.push(node.parentNode);
            if (maxDepth && ++i === maxDepth) {
              break;
            }
            node = node.parentNode;
          }
          return ancestors;
        },
        /***
         * grabArticle - Using a variety of metrics (content score, classname, element types), find the content that is
         *         most likely to be the stuff a user wants to read. Then return it wrapped up in a div.
         *
         * @param page a document to run upon. Needs to be a full document, complete with body.
         * @return Element
         **/
        /* eslint-disable-next-line complexity */
        _grabArticle(page) {
          this.log("**** grabArticle ****");
          var doc = this._doc;
          var isPaging = page !== null;
          page = page ? page : this._doc.body;
          if (!page) {
            this.log("No body found in document. Abort.");
            return null;
          }
          var pageCacheHtml = page.innerHTML;
          while (true) {
            this.log("Starting grabArticle loop");
            var stripUnlikelyCandidates = this._flagIsActive(
              this.FLAG_STRIP_UNLIKELYS
            );
            var elementsToScore = [];
            var node = this._doc.documentElement;
            let shouldRemoveTitleHeader = true;
            while (node) {
              if (node.tagName === "HTML") {
                this._articleLang = node.getAttribute("lang");
              }
              var matchString = node.className + " " + node.id;
              if (!this._isProbablyVisible(node)) {
                this.log("Removing hidden node - " + matchString);
                node = this._removeAndGetNext(node);
                continue;
              }
              if (node.getAttribute("aria-modal") == "true" && node.getAttribute("role") == "dialog") {
                node = this._removeAndGetNext(node);
                continue;
              }
              if (!this._articleByline && !this._metadata.byline && this._isValidByline(node, matchString)) {
                var endOfSearchMarkerNode = this._getNextNode(node, true);
                var next2 = this._getNextNode(node);
                var itemPropNameNode = null;
                while (next2 && next2 != endOfSearchMarkerNode) {
                  var itemprop = next2.getAttribute("itemprop");
                  if (itemprop && itemprop.includes("name")) {
                    itemPropNameNode = next2;
                    break;
                  } else {
                    next2 = this._getNextNode(next2);
                  }
                }
                this._articleByline = (itemPropNameNode ?? node).textContent.trim();
                node = this._removeAndGetNext(node);
                continue;
              }
              if (shouldRemoveTitleHeader && this._headerDuplicatesTitle(node)) {
                this.log(
                  "Removing header: ",
                  node.textContent.trim(),
                  this._articleTitle.trim()
                );
                shouldRemoveTitleHeader = false;
                node = this._removeAndGetNext(node);
                continue;
              }
              if (stripUnlikelyCandidates) {
                if (this.REGEXPS.unlikelyCandidates.test(matchString) && !this.REGEXPS.okMaybeItsACandidate.test(matchString) && !this._hasAncestorTag(node, "table") && !this._hasAncestorTag(node, "code") && node.tagName !== "BODY" && node.tagName !== "A") {
                  this.log("Removing unlikely candidate - " + matchString);
                  node = this._removeAndGetNext(node);
                  continue;
                }
                if (this.UNLIKELY_ROLES.includes(node.getAttribute("role"))) {
                  this.log(
                    "Removing content with role " + node.getAttribute("role") + " - " + matchString
                  );
                  node = this._removeAndGetNext(node);
                  continue;
                }
              }
              if ((node.tagName === "DIV" || node.tagName === "SECTION" || node.tagName === "HEADER" || node.tagName === "H1" || node.tagName === "H2" || node.tagName === "H3" || node.tagName === "H4" || node.tagName === "H5" || node.tagName === "H6") && this._isElementWithoutContent(node)) {
                node = this._removeAndGetNext(node);
                continue;
              }
              if (this.DEFAULT_TAGS_TO_SCORE.includes(node.tagName)) {
                elementsToScore.push(node);
              }
              if (node.tagName === "DIV") {
                var p = null;
                var childNode = node.firstChild;
                while (childNode) {
                  var nextSibling = childNode.nextSibling;
                  if (this._isPhrasingContent(childNode)) {
                    if (p !== null) {
                      p.appendChild(childNode);
                    } else if (!this._isWhitespace(childNode)) {
                      p = doc.createElement("p");
                      node.replaceChild(p, childNode);
                      p.appendChild(childNode);
                    }
                  } else if (p !== null) {
                    while (p.lastChild && this._isWhitespace(p.lastChild)) {
                      p.lastChild.remove();
                    }
                    p = null;
                  }
                  childNode = nextSibling;
                }
                if (this._hasSingleTagInsideElement(node, "P") && this._getLinkDensity(node) < 0.25) {
                  var newNode = node.children[0];
                  node.parentNode.replaceChild(newNode, node);
                  node = newNode;
                  elementsToScore.push(node);
                } else if (!this._hasChildBlockElement(node)) {
                  node = this._setNodeTag(node, "P");
                  elementsToScore.push(node);
                }
              }
              node = this._getNextNode(node);
            }
            var candidates = [];
            this._forEachNode(elementsToScore, function(elementToScore) {
              if (!elementToScore.parentNode || typeof elementToScore.parentNode.tagName === "undefined") {
                return;
              }
              var innerText = this._getInnerText(elementToScore);
              if (innerText.length < 25) {
                return;
              }
              var ancestors2 = this._getNodeAncestors(elementToScore, 5);
              if (ancestors2.length === 0) {
                return;
              }
              var contentScore = 0;
              contentScore += 1;
              contentScore += innerText.split(this.REGEXPS.commas).length;
              contentScore += Math.min(Math.floor(innerText.length / 100), 3);
              this._forEachNode(ancestors2, function(ancestor, level) {
                if (!ancestor.tagName || !ancestor.parentNode || typeof ancestor.parentNode.tagName === "undefined") {
                  return;
                }
                if (typeof ancestor.readability === "undefined") {
                  this._initializeNode(ancestor);
                  candidates.push(ancestor);
                }
                if (level === 0) {
                  var scoreDivider = 1;
                } else if (level === 1) {
                  scoreDivider = 2;
                } else {
                  scoreDivider = level * 3;
                }
                ancestor.readability.contentScore += contentScore / scoreDivider;
              });
            });
            var topCandidates = [];
            for (var c = 0, cl = candidates.length; c < cl; c += 1) {
              var candidate = candidates[c];
              var candidateScore = candidate.readability.contentScore * (1 - this._getLinkDensity(candidate));
              candidate.readability.contentScore = candidateScore;
              this.log("Candidate:", candidate, "with score " + candidateScore);
              for (var t = 0; t < this._nbTopCandidates; t++) {
                var aTopCandidate = topCandidates[t];
                if (!aTopCandidate || candidateScore > aTopCandidate.readability.contentScore) {
                  topCandidates.splice(t, 0, candidate);
                  if (topCandidates.length > this._nbTopCandidates) {
                    topCandidates.pop();
                  }
                  break;
                }
              }
            }
            var topCandidate = topCandidates[0] || null;
            var neededToCreateTopCandidate = false;
            var parentOfTopCandidate;
            if (topCandidate === null || topCandidate.tagName === "BODY") {
              topCandidate = doc.createElement("DIV");
              neededToCreateTopCandidate = true;
              while (page.firstChild) {
                this.log("Moving child out:", page.firstChild);
                topCandidate.appendChild(page.firstChild);
              }
              page.appendChild(topCandidate);
              this._initializeNode(topCandidate);
            } else if (topCandidate) {
              var alternativeCandidateAncestors = [];
              for (var i = 1; i < topCandidates.length; i++) {
                if (topCandidates[i].readability.contentScore / topCandidate.readability.contentScore >= 0.75) {
                  alternativeCandidateAncestors.push(
                    this._getNodeAncestors(topCandidates[i])
                  );
                }
              }
              var MINIMUM_TOPCANDIDATES = 3;
              if (alternativeCandidateAncestors.length >= MINIMUM_TOPCANDIDATES) {
                parentOfTopCandidate = topCandidate.parentNode;
                while (parentOfTopCandidate.tagName !== "BODY") {
                  var listsContainingThisAncestor = 0;
                  for (var ancestorIndex = 0; ancestorIndex < alternativeCandidateAncestors.length && listsContainingThisAncestor < MINIMUM_TOPCANDIDATES; ancestorIndex++) {
                    listsContainingThisAncestor += Number(
                      alternativeCandidateAncestors[ancestorIndex].includes(
                        parentOfTopCandidate
                      )
                    );
                  }
                  if (listsContainingThisAncestor >= MINIMUM_TOPCANDIDATES) {
                    topCandidate = parentOfTopCandidate;
                    break;
                  }
                  parentOfTopCandidate = parentOfTopCandidate.parentNode;
                }
              }
              if (!topCandidate.readability) {
                this._initializeNode(topCandidate);
              }
              parentOfTopCandidate = topCandidate.parentNode;
              var lastScore = topCandidate.readability.contentScore;
              var scoreThreshold = lastScore / 3;
              while (parentOfTopCandidate.tagName !== "BODY") {
                if (!parentOfTopCandidate.readability) {
                  parentOfTopCandidate = parentOfTopCandidate.parentNode;
                  continue;
                }
                var parentScore = parentOfTopCandidate.readability.contentScore;
                if (parentScore < scoreThreshold) {
                  break;
                }
                if (parentScore > lastScore) {
                  topCandidate = parentOfTopCandidate;
                  break;
                }
                lastScore = parentOfTopCandidate.readability.contentScore;
                parentOfTopCandidate = parentOfTopCandidate.parentNode;
              }
              parentOfTopCandidate = topCandidate.parentNode;
              while (parentOfTopCandidate.tagName != "BODY" && parentOfTopCandidate.children.length == 1) {
                topCandidate = parentOfTopCandidate;
                parentOfTopCandidate = topCandidate.parentNode;
              }
              if (!topCandidate.readability) {
                this._initializeNode(topCandidate);
              }
            }
            var articleContent = doc.createElement("DIV");
            if (isPaging) {
              articleContent.id = "readability-content";
            }
            var siblingScoreThreshold = Math.max(
              10,
              topCandidate.readability.contentScore * 0.2
            );
            parentOfTopCandidate = topCandidate.parentNode;
            var siblings = parentOfTopCandidate.children;
            for (var s = 0, sl = siblings.length; s < sl; s++) {
              var sibling = siblings[s];
              var append = false;
              this.log(
                "Looking at sibling node:",
                sibling,
                sibling.readability ? "with score " + sibling.readability.contentScore : ""
              );
              this.log(
                "Sibling has score",
                sibling.readability ? sibling.readability.contentScore : "Unknown"
              );
              if (sibling === topCandidate) {
                append = true;
              } else {
                var contentBonus = 0;
                if (sibling.className === topCandidate.className && topCandidate.className !== "") {
                  contentBonus += topCandidate.readability.contentScore * 0.2;
                }
                if (sibling.readability && sibling.readability.contentScore + contentBonus >= siblingScoreThreshold) {
                  append = true;
                } else if (sibling.nodeName === "P") {
                  var linkDensity = this._getLinkDensity(sibling);
                  var nodeContent = this._getInnerText(sibling);
                  var nodeLength = nodeContent.length;
                  if (nodeLength > 80 && linkDensity < 0.25) {
                    append = true;
                  } else if (nodeLength < 80 && nodeLength > 0 && linkDensity === 0 && nodeContent.search(/\.( |$)/) !== -1) {
                    append = true;
                  }
                }
              }
              if (append) {
                this.log("Appending node:", sibling);
                if (!this.ALTER_TO_DIV_EXCEPTIONS.includes(sibling.nodeName)) {
                  this.log("Altering sibling:", sibling, "to div.");
                  sibling = this._setNodeTag(sibling, "DIV");
                }
                articleContent.appendChild(sibling);
                siblings = parentOfTopCandidate.children;
                s -= 1;
                sl -= 1;
              }
            }
            if (this._debug) {
              this.log("Article content pre-prep: " + articleContent.innerHTML);
            }
            this._prepArticle(articleContent);
            if (this._debug) {
              this.log("Article content post-prep: " + articleContent.innerHTML);
            }
            if (neededToCreateTopCandidate) {
              topCandidate.id = "readability-page-1";
              topCandidate.className = "page";
            } else {
              var div = doc.createElement("DIV");
              div.id = "readability-page-1";
              div.className = "page";
              while (articleContent.firstChild) {
                div.appendChild(articleContent.firstChild);
              }
              articleContent.appendChild(div);
            }
            if (this._debug) {
              this.log("Article content after paging: " + articleContent.innerHTML);
            }
            var parseSuccessful = true;
            var textLength = this._getInnerText(articleContent, true).length;
            if (textLength < this._charThreshold) {
              parseSuccessful = false;
              page.innerHTML = pageCacheHtml;
              this._attempts.push({
                articleContent,
                textLength
              });
              if (this._flagIsActive(this.FLAG_STRIP_UNLIKELYS)) {
                this._removeFlag(this.FLAG_STRIP_UNLIKELYS);
              } else if (this._flagIsActive(this.FLAG_WEIGHT_CLASSES)) {
                this._removeFlag(this.FLAG_WEIGHT_CLASSES);
              } else if (this._flagIsActive(this.FLAG_CLEAN_CONDITIONALLY)) {
                this._removeFlag(this.FLAG_CLEAN_CONDITIONALLY);
              } else {
                this._attempts.sort(function(a, b) {
                  return b.textLength - a.textLength;
                });
                if (!this._attempts[0].textLength) {
                  return null;
                }
                articleContent = this._attempts[0].articleContent;
                parseSuccessful = true;
              }
            }
            if (parseSuccessful) {
              var ancestors = [parentOfTopCandidate, topCandidate].concat(
                this._getNodeAncestors(parentOfTopCandidate)
              );
              this._someNode(ancestors, function(ancestor) {
                if (!ancestor.tagName) {
                  return false;
                }
                var articleDir = ancestor.getAttribute("dir");
                if (articleDir) {
                  this._articleDir = articleDir;
                  return true;
                }
                return false;
              });
              return articleContent;
            }
          }
        },
        /**
         * Converts some of the common HTML entities in string to their corresponding characters.
         *
         * @param str {string} - a string to unescape.
         * @return string without HTML entity.
         */
        _unescapeHtmlEntities(str) {
          if (!str) {
            return str;
          }
          var htmlEscapeMap = this.HTML_ESCAPE_MAP;
          return str.replace(/&(quot|amp|apos|lt|gt);/g, function(_, tag) {
            return htmlEscapeMap[tag];
          }).replace(/&#(?:x([0-9a-f]+)|([0-9]+));/gi, function(_, hex, numStr) {
            var num = parseInt(hex || numStr, hex ? 16 : 10);
            if (num == 0 || num > 1114111 || num >= 55296 && num <= 57343) {
              num = 65533;
            }
            return String.fromCodePoint(num);
          });
        },
        /**
         * Try to extract metadata from JSON-LD object.
         * For now, only Schema.org objects of type Article or its subtypes are supported.
         * @return Object with any metadata that could be extracted (possibly none)
         */
        _getJSONLD(doc) {
          var scripts = this._getAllNodesWithTag(doc, ["script"]);
          var metadata;
          this._forEachNode(scripts, function(jsonLdElement) {
            if (!metadata && jsonLdElement.getAttribute("type") === "application/ld+json") {
              try {
                var content = jsonLdElement.textContent.replace(
                  /^\s*<!\[CDATA\[|\]\]>\s*$/g,
                  ""
                );
                var parsed = JSON.parse(content);
                if (Array.isArray(parsed)) {
                  parsed = parsed.find((it) => {
                    return it["@type"] && it["@type"].match(this.REGEXPS.jsonLdArticleTypes);
                  });
                  if (!parsed) {
                    return;
                  }
                }
                var schemaDotOrgRegex = /^https?\:\/\/schema\.org\/?$/;
                var matches = typeof parsed["@context"] === "string" && parsed["@context"].match(schemaDotOrgRegex) || typeof parsed["@context"] === "object" && typeof parsed["@context"]["@vocab"] == "string" && parsed["@context"]["@vocab"].match(schemaDotOrgRegex);
                if (!matches) {
                  return;
                }
                if (!parsed["@type"] && Array.isArray(parsed["@graph"])) {
                  parsed = parsed["@graph"].find((it) => {
                    return (it["@type"] || "").match(this.REGEXPS.jsonLdArticleTypes);
                  });
                }
                if (!parsed || !parsed["@type"] || !parsed["@type"].match(this.REGEXPS.jsonLdArticleTypes)) {
                  return;
                }
                metadata = {};
                if (typeof parsed.name === "string" && typeof parsed.headline === "string" && parsed.name !== parsed.headline) {
                  var title = this._getArticleTitle();
                  var nameMatches = this._textSimilarity(parsed.name, title) > 0.75;
                  var headlineMatches = this._textSimilarity(parsed.headline, title) > 0.75;
                  if (headlineMatches && !nameMatches) {
                    metadata.title = parsed.headline;
                  } else {
                    metadata.title = parsed.name;
                  }
                } else if (typeof parsed.name === "string") {
                  metadata.title = parsed.name.trim();
                } else if (typeof parsed.headline === "string") {
                  metadata.title = parsed.headline.trim();
                }
                if (parsed.author) {
                  if (typeof parsed.author.name === "string") {
                    metadata.byline = parsed.author.name.trim();
                  } else if (Array.isArray(parsed.author) && parsed.author[0] && typeof parsed.author[0].name === "string") {
                    metadata.byline = parsed.author.filter(function(author) {
                      return author && typeof author.name === "string";
                    }).map(function(author) {
                      return author.name.trim();
                    }).join(", ");
                  }
                }
                if (typeof parsed.description === "string") {
                  metadata.excerpt = parsed.description.trim();
                }
                if (parsed.publisher && typeof parsed.publisher.name === "string") {
                  metadata.siteName = parsed.publisher.name.trim();
                }
                if (typeof parsed.datePublished === "string") {
                  metadata.datePublished = parsed.datePublished.trim();
                }
              } catch (err) {
                this.log(err.message);
              }
            }
          });
          return metadata ? metadata : {};
        },
        /**
         * Attempts to get excerpt and byline metadata for the article.
         *
         * @param {Object} jsonld — object containing any metadata that
         * could be extracted from JSON-LD object.
         *
         * @return Object with optional "excerpt" and "byline" properties
         */
        _getArticleMetadata(jsonld) {
          var metadata = {};
          var values = {};
          var metaElements = this._doc.getElementsByTagName("meta");
          var propertyPattern = /\s*(article|dc|dcterm|og|twitter)\s*:\s*(author|creator|description|published_time|title|site_name)\s*/gi;
          var namePattern = /^\s*(?:(dc|dcterm|og|twitter|parsely|weibo:(article|webpage))\s*[-\.:]\s*)?(author|creator|pub-date|description|title|site_name)\s*$/i;
          this._forEachNode(metaElements, function(element) {
            var elementName = element.getAttribute("name");
            var elementProperty = element.getAttribute("property");
            var content = element.getAttribute("content");
            if (!content) {
              return;
            }
            var matches = null;
            var name = null;
            if (elementProperty) {
              matches = elementProperty.match(propertyPattern);
              if (matches) {
                name = matches[0].toLowerCase().replace(/\s/g, "");
                values[name] = content.trim();
              }
            }
            if (!matches && elementName && namePattern.test(elementName)) {
              name = elementName;
              if (content) {
                name = name.toLowerCase().replace(/\s/g, "").replace(/\./g, ":");
                values[name] = content.trim();
              }
            }
          });
          metadata.title = jsonld.title || values["dc:title"] || values["dcterm:title"] || values["og:title"] || values["weibo:article:title"] || values["weibo:webpage:title"] || values.title || values["twitter:title"] || values["parsely-title"];
          if (!metadata.title) {
            metadata.title = this._getArticleTitle();
          }
          const articleAuthor = typeof values["article:author"] === "string" && !this._isUrl(values["article:author"]) ? values["article:author"] : void 0;
          metadata.byline = jsonld.byline || values["dc:creator"] || values["dcterm:creator"] || values.author || values["parsely-author"] || articleAuthor;
          metadata.excerpt = jsonld.excerpt || values["dc:description"] || values["dcterm:description"] || values["og:description"] || values["weibo:article:description"] || values["weibo:webpage:description"] || values.description || values["twitter:description"];
          metadata.siteName = jsonld.siteName || values["og:site_name"];
          metadata.publishedTime = jsonld.datePublished || values["article:published_time"] || values["parsely-pub-date"] || null;
          metadata.title = this._unescapeHtmlEntities(metadata.title);
          metadata.byline = this._unescapeHtmlEntities(metadata.byline);
          metadata.excerpt = this._unescapeHtmlEntities(metadata.excerpt);
          metadata.siteName = this._unescapeHtmlEntities(metadata.siteName);
          metadata.publishedTime = this._unescapeHtmlEntities(metadata.publishedTime);
          return metadata;
        },
        /**
         * Check if node is image, or if node contains exactly only one image
         * whether as a direct child or as its descendants.
         *
         * @param Element
         **/
        _isSingleImage(node) {
          while (node) {
            if (node.tagName === "IMG") {
              return true;
            }
            if (node.children.length !== 1 || node.textContent.trim() !== "") {
              return false;
            }
            node = node.children[0];
          }
          return false;
        },
        /**
         * Find all <noscript> that are located after <img> nodes, and which contain only one
         * <img> element. Replace the first image with the image from inside the <noscript> tag,
         * and remove the <noscript> tag. This improves the quality of the images we use on
         * some sites (e.g. Medium).
         *
         * @param Element
         **/
        _unwrapNoscriptImages(doc) {
          var imgs = Array.from(doc.getElementsByTagName("img"));
          this._forEachNode(imgs, function(img) {
            for (var i = 0; i < img.attributes.length; i++) {
              var attr = img.attributes[i];
              switch (attr.name) {
                case "src":
                case "srcset":
                case "data-src":
                case "data-srcset":
                  return;
              }
              if (/\.(jpg|jpeg|png|webp)/i.test(attr.value)) {
                return;
              }
            }
            img.remove();
          });
          var noscripts = Array.from(doc.getElementsByTagName("noscript"));
          this._forEachNode(noscripts, function(noscript) {
            if (!this._isSingleImage(noscript)) {
              return;
            }
            var tmp = doc.createElement("div");
            tmp.innerHTML = noscript.innerHTML;
            var prevElement = noscript.previousElementSibling;
            if (prevElement && this._isSingleImage(prevElement)) {
              var prevImg = prevElement;
              if (prevImg.tagName !== "IMG") {
                prevImg = prevElement.getElementsByTagName("img")[0];
              }
              var newImg = tmp.getElementsByTagName("img")[0];
              for (var i = 0; i < prevImg.attributes.length; i++) {
                var attr = prevImg.attributes[i];
                if (attr.value === "") {
                  continue;
                }
                if (attr.name === "src" || attr.name === "srcset" || /\.(jpg|jpeg|png|webp)/i.test(attr.value)) {
                  if (newImg.getAttribute(attr.name) === attr.value) {
                    continue;
                  }
                  var attrName = attr.name;
                  if (newImg.hasAttribute(attrName)) {
                    attrName = "data-old-" + attrName;
                  }
                  newImg.setAttribute(attrName, attr.value);
                }
              }
              noscript.parentNode.replaceChild(tmp.firstElementChild, prevElement);
            }
          });
        },
        /**
         * Removes script tags from the document.
         *
         * @param Element
         **/
        _removeScripts(doc) {
          this._removeNodes(this._getAllNodesWithTag(doc, ["script", "noscript"]));
        },
        /**
         * Check if this node has only whitespace and a single element with given tag
         * Returns false if the DIV node contains non-empty text nodes
         * or if it contains no element with given tag or more than 1 element.
         *
         * @param Element
         * @param string tag of child element
         **/
        _hasSingleTagInsideElement(element, tag) {
          if (element.children.length != 1 || element.children[0].tagName !== tag) {
            return false;
          }
          return !this._someNode(element.childNodes, function(node) {
            return node.nodeType === this.TEXT_NODE && this.REGEXPS.hasContent.test(node.textContent);
          });
        },
        _isElementWithoutContent(node) {
          return node.nodeType === this.ELEMENT_NODE && !node.textContent.trim().length && (!node.children.length || node.children.length == node.getElementsByTagName("br").length + node.getElementsByTagName("hr").length);
        },
        /**
         * Determine whether element has any children block level elements.
         *
         * @param Element
         */
        _hasChildBlockElement(element) {
          return this._someNode(element.childNodes, function(node) {
            return this.DIV_TO_P_ELEMS.has(node.tagName) || this._hasChildBlockElement(node);
          });
        },
        /***
         * Determine if a node qualifies as phrasing content.
         * https://developer.mozilla.org/en-US/docs/Web/Guide/HTML/Content_categories#Phrasing_content
         **/
        _isPhrasingContent(node) {
          return node.nodeType === this.TEXT_NODE || this.PHRASING_ELEMS.includes(node.tagName) || (node.tagName === "A" || node.tagName === "DEL" || node.tagName === "INS") && this._everyNode(node.childNodes, this._isPhrasingContent);
        },
        _isWhitespace(node) {
          return node.nodeType === this.TEXT_NODE && node.textContent.trim().length === 0 || node.nodeType === this.ELEMENT_NODE && node.tagName === "BR";
        },
        /**
         * Get the inner text of a node - cross browser compatibly.
         * This also strips out any excess whitespace to be found.
         *
         * @param Element
         * @param Boolean normalizeSpaces (default: true)
         * @return string
         **/
        _getInnerText(e, normalizeSpaces) {
          normalizeSpaces = typeof normalizeSpaces === "undefined" ? true : normalizeSpaces;
          var textContent = e.textContent.trim();
          if (normalizeSpaces) {
            return textContent.replace(this.REGEXPS.normalize, " ");
          }
          return textContent;
        },
        /**
         * Get the number of times a string s appears in the node e.
         *
         * @param Element
         * @param string - what to split on. Default is ","
         * @return number (integer)
         **/
        _getCharCount(e, s) {
          s = s || ",";
          return this._getInnerText(e).split(s).length - 1;
        },
        /**
         * Remove the style attribute on every e and under.
         * TODO: Test if getElementsByTagName(*) is faster.
         *
         * @param Element
         * @return void
         **/
        _cleanStyles(e) {
          if (!e || e.tagName.toLowerCase() === "svg") {
            return;
          }
          for (var i = 0; i < this.PRESENTATIONAL_ATTRIBUTES.length; i++) {
            e.removeAttribute(this.PRESENTATIONAL_ATTRIBUTES[i]);
          }
          if (this.DEPRECATED_SIZE_ATTRIBUTE_ELEMS.includes(e.tagName)) {
            e.removeAttribute("width");
            e.removeAttribute("height");
          }
          var cur = e.firstElementChild;
          while (cur !== null) {
            this._cleanStyles(cur);
            cur = cur.nextElementSibling;
          }
        },
        /**
         * Get the density of links as a percentage of the content
         * This is the amount of text that is inside a link divided by the total text in the node.
         *
         * @param Element
         * @return number (float)
         **/
        _getLinkDensity(element) {
          var textLength = this._getInnerText(element).length;
          if (textLength === 0) {
            return 0;
          }
          var linkLength = 0;
          this._forEachNode(element.getElementsByTagName("a"), function(linkNode) {
            var href = linkNode.getAttribute("href");
            var coefficient = href && this.REGEXPS.hashUrl.test(href) ? 0.3 : 1;
            linkLength += this._getInnerText(linkNode).length * coefficient;
          });
          return linkLength / textLength;
        },
        /**
         * Get an elements class/id weight. Uses regular expressions to tell if this
         * element looks good or bad.
         *
         * @param Element
         * @return number (Integer)
         **/
        _getClassWeight(e) {
          if (!this._flagIsActive(this.FLAG_WEIGHT_CLASSES)) {
            return 0;
          }
          var weight = 0;
          if (typeof e.className === "string" && e.className !== "") {
            if (this.REGEXPS.negative.test(e.className)) {
              weight -= 25;
            }
            if (this.REGEXPS.positive.test(e.className)) {
              weight += 25;
            }
          }
          if (typeof e.id === "string" && e.id !== "") {
            if (this.REGEXPS.negative.test(e.id)) {
              weight -= 25;
            }
            if (this.REGEXPS.positive.test(e.id)) {
              weight += 25;
            }
          }
          return weight;
        },
        /**
         * Clean a node of all elements of type "tag".
         * (Unless it's a youtube/vimeo video. People love movies.)
         *
         * @param Element
         * @param string tag to clean
         * @return void
         **/
        _clean(e, tag) {
          var isEmbed = ["object", "embed", "iframe"].includes(tag);
          this._removeNodes(this._getAllNodesWithTag(e, [tag]), function(element) {
            if (isEmbed) {
              for (var i = 0; i < element.attributes.length; i++) {
                if (this._allowedVideoRegex.test(element.attributes[i].value)) {
                  return false;
                }
              }
              if (element.tagName === "object" && this._allowedVideoRegex.test(element.innerHTML)) {
                return false;
              }
            }
            return true;
          });
        },
        /**
         * Check if a given node has one of its ancestor tag name matching the
         * provided one.
         * @param  HTMLElement node
         * @param  String      tagName
         * @param  Number      maxDepth
         * @param  Function    filterFn a filter to invoke to determine whether this node 'counts'
         * @return Boolean
         */
        _hasAncestorTag(node, tagName, maxDepth, filterFn) {
          maxDepth = maxDepth || 3;
          tagName = tagName.toUpperCase();
          var depth = 0;
          while (node.parentNode) {
            if (maxDepth > 0 && depth > maxDepth) {
              return false;
            }
            if (node.parentNode.tagName === tagName && (!filterFn || filterFn(node.parentNode))) {
              return true;
            }
            node = node.parentNode;
            depth++;
          }
          return false;
        },
        /**
         * Return an object indicating how many rows and columns this table has.
         */
        _getRowAndColumnCount(table) {
          var rows = 0;
          var columns = 0;
          var trs = table.getElementsByTagName("tr");
          for (var i = 0; i < trs.length; i++) {
            var rowspan = trs[i].getAttribute("rowspan") || 0;
            if (rowspan) {
              rowspan = parseInt(rowspan, 10);
            }
            rows += rowspan || 1;
            var columnsInThisRow = 0;
            var cells = trs[i].getElementsByTagName("td");
            for (var j = 0; j < cells.length; j++) {
              var colspan = cells[j].getAttribute("colspan") || 0;
              if (colspan) {
                colspan = parseInt(colspan, 10);
              }
              columnsInThisRow += colspan || 1;
            }
            columns = Math.max(columns, columnsInThisRow);
          }
          return { rows, columns };
        },
        /**
         * Look for 'data' (as opposed to 'layout') tables, for which we use
         * similar checks as
         * https://searchfox.org/mozilla-central/rev/f82d5c549f046cb64ce5602bfd894b7ae807c8f8/accessible/generic/TableAccessible.cpp#19
         */
        _markDataTables(root2) {
          var tables = root2.getElementsByTagName("table");
          for (var i = 0; i < tables.length; i++) {
            var table = tables[i];
            var role = table.getAttribute("role");
            if (role == "presentation") {
              table._readabilityDataTable = false;
              continue;
            }
            var datatable = table.getAttribute("datatable");
            if (datatable == "0") {
              table._readabilityDataTable = false;
              continue;
            }
            var summary = table.getAttribute("summary");
            if (summary) {
              table._readabilityDataTable = true;
              continue;
            }
            var caption = table.getElementsByTagName("caption")[0];
            if (caption && caption.childNodes.length) {
              table._readabilityDataTable = true;
              continue;
            }
            var dataTableDescendants = ["col", "colgroup", "tfoot", "thead", "th"];
            var descendantExists = function(tag) {
              return !!table.getElementsByTagName(tag)[0];
            };
            if (dataTableDescendants.some(descendantExists)) {
              this.log("Data table because found data-y descendant");
              table._readabilityDataTable = true;
              continue;
            }
            if (table.getElementsByTagName("table")[0]) {
              table._readabilityDataTable = false;
              continue;
            }
            var sizeInfo = this._getRowAndColumnCount(table);
            if (sizeInfo.columns == 1 || sizeInfo.rows == 1) {
              table._readabilityDataTable = false;
              continue;
            }
            if (sizeInfo.rows >= 10 || sizeInfo.columns > 4) {
              table._readabilityDataTable = true;
              continue;
            }
            table._readabilityDataTable = sizeInfo.rows * sizeInfo.columns > 10;
          }
        },
        /* convert images and figures that have properties like data-src into images that can be loaded without JS */
        _fixLazyImages(root2) {
          this._forEachNode(
            this._getAllNodesWithTag(root2, ["img", "picture", "figure"]),
            function(elem) {
              if (elem.src && this.REGEXPS.b64DataUrl.test(elem.src)) {
                var parts = this.REGEXPS.b64DataUrl.exec(elem.src);
                if (parts[1] === "image/svg+xml") {
                  return;
                }
                var srcCouldBeRemoved = false;
                for (var i = 0; i < elem.attributes.length; i++) {
                  var attr = elem.attributes[i];
                  if (attr.name === "src") {
                    continue;
                  }
                  if (/\.(jpg|jpeg|png|webp)/i.test(attr.value)) {
                    srcCouldBeRemoved = true;
                    break;
                  }
                }
                if (srcCouldBeRemoved) {
                  var b64starts = parts[0].length;
                  var b64length = elem.src.length - b64starts;
                  if (b64length < 133) {
                    elem.removeAttribute("src");
                  }
                }
              }
              if ((elem.src || elem.srcset && elem.srcset != "null") && !elem.className.toLowerCase().includes("lazy")) {
                return;
              }
              for (var j = 0; j < elem.attributes.length; j++) {
                attr = elem.attributes[j];
                if (attr.name === "src" || attr.name === "srcset" || attr.name === "alt") {
                  continue;
                }
                var copyTo = null;
                if (/\.(jpg|jpeg|png|webp)\s+\d/.test(attr.value)) {
                  copyTo = "srcset";
                } else if (/^\s*\S+\.(jpg|jpeg|png|webp)\S*\s*$/.test(attr.value)) {
                  copyTo = "src";
                }
                if (copyTo) {
                  if (elem.tagName === "IMG" || elem.tagName === "PICTURE") {
                    elem.setAttribute(copyTo, attr.value);
                  } else if (elem.tagName === "FIGURE" && !this._getAllNodesWithTag(elem, ["img", "picture"]).length) {
                    var img = this._doc.createElement("img");
                    img.setAttribute(copyTo, attr.value);
                    elem.appendChild(img);
                  }
                }
              }
            }
          );
        },
        _getTextDensity(e, tags) {
          var textLength = this._getInnerText(e, true).length;
          if (textLength === 0) {
            return 0;
          }
          var childrenLength = 0;
          var children = this._getAllNodesWithTag(e, tags);
          this._forEachNode(
            children,
            (child) => childrenLength += this._getInnerText(child, true).length
          );
          return childrenLength / textLength;
        },
        /**
         * Clean an element of all tags of type "tag" if they look fishy.
         * "Fishy" is an algorithm based on content length, classnames, link density, number of images & embeds, etc.
         *
         * @return void
         **/
        _cleanConditionally(e, tag) {
          if (!this._flagIsActive(this.FLAG_CLEAN_CONDITIONALLY)) {
            return;
          }
          this._removeNodes(this._getAllNodesWithTag(e, [tag]), function(node) {
            var isDataTable = function(t) {
              return t._readabilityDataTable;
            };
            var isList = tag === "ul" || tag === "ol";
            if (!isList) {
              var listLength = 0;
              var listNodes = this._getAllNodesWithTag(node, ["ul", "ol"]);
              this._forEachNode(
                listNodes,
                (list) => listLength += this._getInnerText(list).length
              );
              isList = listLength / this._getInnerText(node).length > 0.9;
            }
            if (tag === "table" && isDataTable(node)) {
              return false;
            }
            if (this._hasAncestorTag(node, "table", -1, isDataTable)) {
              return false;
            }
            if (this._hasAncestorTag(node, "code")) {
              return false;
            }
            if ([...node.getElementsByTagName("table")].some(
              (tbl) => tbl._readabilityDataTable
            )) {
              return false;
            }
            var weight = this._getClassWeight(node);
            this.log("Cleaning Conditionally", node);
            var contentScore = 0;
            if (weight + contentScore < 0) {
              return true;
            }
            if (this._getCharCount(node, ",") < 10) {
              var p = node.getElementsByTagName("p").length;
              var img = node.getElementsByTagName("img").length;
              var li = node.getElementsByTagName("li").length - 100;
              var input = node.getElementsByTagName("input").length;
              var headingDensity = this._getTextDensity(node, [
                "h1",
                "h2",
                "h3",
                "h4",
                "h5",
                "h6"
              ]);
              var embedCount = 0;
              var embeds = this._getAllNodesWithTag(node, [
                "object",
                "embed",
                "iframe"
              ]);
              for (var i = 0; i < embeds.length; i++) {
                for (var j = 0; j < embeds[i].attributes.length; j++) {
                  if (this._allowedVideoRegex.test(embeds[i].attributes[j].value)) {
                    return false;
                  }
                }
                if (embeds[i].tagName === "object" && this._allowedVideoRegex.test(embeds[i].innerHTML)) {
                  return false;
                }
                embedCount++;
              }
              var innerText = this._getInnerText(node);
              if (this.REGEXPS.adWords.test(innerText) || this.REGEXPS.loadingWords.test(innerText)) {
                return true;
              }
              var contentLength = innerText.length;
              var linkDensity = this._getLinkDensity(node);
              var textishTags = ["SPAN", "LI", "TD"].concat(
                Array.from(this.DIV_TO_P_ELEMS)
              );
              var textDensity = this._getTextDensity(node, textishTags);
              var isFigureChild = this._hasAncestorTag(node, "figure");
              const shouldRemoveNode = () => {
                const errs = [];
                if (!isFigureChild && img > 1 && p / img < 0.5) {
                  errs.push(`Bad p to img ratio (img=${img}, p=${p})`);
                }
                if (!isList && li > p) {
                  errs.push(`Too many li's outside of a list. (li=${li} > p=${p})`);
                }
                if (input > Math.floor(p / 3)) {
                  errs.push(`Too many inputs per p. (input=${input}, p=${p})`);
                }
                if (!isList && !isFigureChild && headingDensity < 0.9 && contentLength < 25 && (img === 0 || img > 2) && linkDensity > 0) {
                  errs.push(
                    `Suspiciously short. (headingDensity=${headingDensity}, img=${img}, linkDensity=${linkDensity})`
                  );
                }
                if (!isList && weight < 25 && linkDensity > 0.2 + this._linkDensityModifier) {
                  errs.push(
                    `Low weight and a little linky. (linkDensity=${linkDensity})`
                  );
                }
                if (weight >= 25 && linkDensity > 0.5 + this._linkDensityModifier) {
                  errs.push(
                    `High weight and mostly links. (linkDensity=${linkDensity})`
                  );
                }
                if (embedCount === 1 && contentLength < 75 || embedCount > 1) {
                  errs.push(
                    `Suspicious embed. (embedCount=${embedCount}, contentLength=${contentLength})`
                  );
                }
                if (img === 0 && textDensity === 0) {
                  errs.push(
                    `No useful content. (img=${img}, textDensity=${textDensity})`
                  );
                }
                if (errs.length) {
                  this.log("Checks failed", errs);
                  return true;
                }
                return false;
              };
              var haveToRemove = shouldRemoveNode();
              if (isList && haveToRemove) {
                for (var x = 0; x < node.children.length; x++) {
                  let child = node.children[x];
                  if (child.children.length > 1) {
                    return haveToRemove;
                  }
                }
                let li_count = node.getElementsByTagName("li").length;
                if (img == li_count) {
                  return false;
                }
              }
              return haveToRemove;
            }
            return false;
          });
        },
        /**
         * Clean out elements that match the specified conditions
         *
         * @param Element
         * @param Function determines whether a node should be removed
         * @return void
         **/
        _cleanMatchedNodes(e, filter) {
          var endOfSearchMarkerNode = this._getNextNode(e, true);
          var next2 = this._getNextNode(e);
          while (next2 && next2 != endOfSearchMarkerNode) {
            if (filter.call(this, next2, next2.className + " " + next2.id)) {
              next2 = this._removeAndGetNext(next2);
            } else {
              next2 = this._getNextNode(next2);
            }
          }
        },
        /**
         * Clean out spurious headers from an Element.
         *
         * @param Element
         * @return void
         **/
        _cleanHeaders(e) {
          let headingNodes = this._getAllNodesWithTag(e, ["h1", "h2"]);
          this._removeNodes(headingNodes, function(node) {
            let shouldRemove = this._getClassWeight(node) < 0;
            if (shouldRemove) {
              this.log("Removing header with low class weight:", node);
            }
            return shouldRemove;
          });
        },
        /**
         * Check if this node is an H1 or H2 element whose content is mostly
         * the same as the article title.
         *
         * @param Element  the node to check.
         * @return boolean indicating whether this is a title-like header.
         */
        _headerDuplicatesTitle(node) {
          if (node.tagName != "H1" && node.tagName != "H2") {
            return false;
          }
          var heading = this._getInnerText(node, false);
          this.log("Evaluating similarity of header:", heading, this._articleTitle);
          return this._textSimilarity(this._articleTitle, heading) > 0.75;
        },
        _flagIsActive(flag) {
          return (this._flags & flag) > 0;
        },
        _removeFlag(flag) {
          this._flags = this._flags & ~flag;
        },
        _isProbablyVisible(node) {
          return (!node.style || node.style.display != "none") && (!node.style || node.style.visibility != "hidden") && !node.hasAttribute("hidden") && //check for "fallback-image" so that wikimedia math images are displayed
          (!node.hasAttribute("aria-hidden") || node.getAttribute("aria-hidden") != "true" || node.className && node.className.includes && node.className.includes("fallback-image"));
        },
        /**
         * Runs readability.
         *
         * Workflow:
         *  1. Prep the document by removing script tags, css, etc.
         *  2. Build readability's DOM tree.
         *  3. Grab the article content from the current dom tree.
         *  4. Replace the current DOM tree with the new one.
         *  5. Read peacefully.
         *
         * @return void
         **/
        parse() {
          if (this._maxElemsToParse > 0) {
            var numTags = this._doc.getElementsByTagName("*").length;
            if (numTags > this._maxElemsToParse) {
              throw new Error(
                "Aborting parsing document; " + numTags + " elements found"
              );
            }
          }
          this._unwrapNoscriptImages(this._doc);
          var jsonLd = this._disableJSONLD ? {} : this._getJSONLD(this._doc);
          this._removeScripts(this._doc);
          this._prepDocument();
          var metadata = this._getArticleMetadata(jsonLd);
          this._metadata = metadata;
          this._articleTitle = metadata.title;
          var articleContent = this._grabArticle();
          if (!articleContent) {
            return null;
          }
          this.log("Grabbed: " + articleContent.innerHTML);
          this._postProcessContent(articleContent);
          if (!metadata.excerpt) {
            var paragraphs = articleContent.getElementsByTagName("p");
            if (paragraphs.length) {
              metadata.excerpt = paragraphs[0].textContent.trim();
            }
          }
          var textContent = articleContent.textContent;
          return {
            title: this._articleTitle,
            byline: metadata.byline || this._articleByline,
            dir: this._articleDir,
            lang: this._articleLang,
            content: this._serializer(articleContent),
            textContent,
            length: textContent.length,
            excerpt: metadata.excerpt,
            siteName: metadata.siteName || this._articleSiteName,
            publishedTime: metadata.publishedTime
          };
        }
      };
      if (typeof module === "object") {
        module.exports = Readability2;
      }
    }
  });

  // node_modules/@mozilla/readability/Readability-readerable.js
  var require_Readability_readerable = __commonJS({
    "node_modules/@mozilla/readability/Readability-readerable.js"(exports, module) {
      var REGEXPS = {
        // NOTE: These two regular expressions are duplicated in
        // Readability.js. Please keep both copies in sync.
        unlikelyCandidates: /-ad-|ai2html|banner|breadcrumbs|combx|comment|community|cover-wrap|disqus|extra|footer|gdpr|header|legends|menu|related|remark|replies|rss|shoutbox|sidebar|skyscraper|social|sponsor|supplemental|ad-break|agegate|pagination|pager|popup|yom-remote/i,
        okMaybeItsACandidate: /and|article|body|column|content|main|shadow/i
      };
      function isNodeVisible(node) {
        return (!node.style || node.style.display != "none") && !node.hasAttribute("hidden") && //check for "fallback-image" so that wikimedia math images are displayed
        (!node.hasAttribute("aria-hidden") || node.getAttribute("aria-hidden") != "true" || node.className && node.className.includes && node.className.includes("fallback-image"));
      }
      function isProbablyReaderable(doc, options = {}) {
        if (typeof options == "function") {
          options = { visibilityChecker: options };
        }
        var defaultOptions = {
          minScore: 20,
          minContentLength: 140,
          visibilityChecker: isNodeVisible
        };
        options = Object.assign(defaultOptions, options);
        var nodes = doc.querySelectorAll("p, pre, article");
        var brNodes = doc.querySelectorAll("div > br");
        if (brNodes.length) {
          var set = new Set(nodes);
          [].forEach.call(brNodes, function(node) {
            set.add(node.parentNode);
          });
          nodes = Array.from(set);
        }
        var score = 0;
        return [].some.call(nodes, function(node) {
          if (!options.visibilityChecker(node)) {
            return false;
          }
          var matchString = node.className + " " + node.id;
          if (REGEXPS.unlikelyCandidates.test(matchString) && !REGEXPS.okMaybeItsACandidate.test(matchString)) {
            return false;
          }
          if (node.matches("li p")) {
            return false;
          }
          var textContentLength = node.textContent.trim().length;
          if (textContentLength < options.minContentLength) {
            return false;
          }
          score += Math.sqrt(textContentLength - options.minContentLength);
          if (score > options.minScore) {
            return true;
          }
          return false;
        });
      }
      if (typeof module === "object") {
        module.exports = isProbablyReaderable;
      }
    }
  });

  // node_modules/@mozilla/readability/index.js
  var require_readability = __commonJS({
    "node_modules/@mozilla/readability/index.js"(exports, module) {
      var Readability2 = require_Readability();
      var isProbablyReaderable = require_Readability_readerable();
      module.exports = {
        Readability: Readability2,
        isProbablyReaderable
      };
    }
  });

  // core/errors.ts
  function errorDetails(value) {
    return typeof value === "object" && value !== null ? value : {};
  }
  function failure(code, details = {}) {
    return Object.assign(new Error(code), { code, ...details });
  }

  // core/content/article.ts
  var import_readability = __toESM(require_readability(), 1);

  // node_modules/turndown/lib/turndown.browser.es.js
  function extend(destination) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];
      for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) destination[key] = source[key];
      }
    }
    return destination;
  }
  function repeat(character, count) {
    return Array(count + 1).join(character);
  }
  function trimLeadingNewlines(string) {
    return string.replace(/^\n*/, "");
  }
  function trimTrailingNewlines(string) {
    var indexEnd = string.length;
    while (indexEnd > 0 && string[indexEnd - 1] === "\n") indexEnd--;
    return string.substring(0, indexEnd);
  }
  function trimNewlines(string) {
    return trimTrailingNewlines(trimLeadingNewlines(string));
  }
  var blockElements = ["ADDRESS", "ARTICLE", "ASIDE", "AUDIO", "BLOCKQUOTE", "BODY", "CANVAS", "CENTER", "DD", "DIR", "DIV", "DL", "DT", "FIELDSET", "FIGCAPTION", "FIGURE", "FOOTER", "FORM", "FRAMESET", "H1", "H2", "H3", "H4", "H5", "H6", "HEADER", "HGROUP", "HR", "HTML", "ISINDEX", "LI", "MAIN", "MENU", "NAV", "NOFRAMES", "NOSCRIPT", "OL", "OUTPUT", "P", "PRE", "SECTION", "TABLE", "TBODY", "TD", "TFOOT", "TH", "THEAD", "TR", "UL"];
  function isBlock(node) {
    return is(node, blockElements);
  }
  var voidElements = ["AREA", "BASE", "BR", "COL", "COMMAND", "EMBED", "HR", "IMG", "INPUT", "KEYGEN", "LINK", "META", "PARAM", "SOURCE", "TRACK", "WBR"];
  function isVoid(node) {
    return is(node, voidElements);
  }
  function hasVoid(node) {
    return has(node, voidElements);
  }
  var meaningfulWhenBlankElements = ["A", "TABLE", "THEAD", "TBODY", "TFOOT", "TH", "TD", "IFRAME", "SCRIPT", "AUDIO", "VIDEO"];
  function isMeaningfulWhenBlank(node) {
    return is(node, meaningfulWhenBlankElements);
  }
  function hasMeaningfulWhenBlank(node) {
    return has(node, meaningfulWhenBlankElements);
  }
  function is(node, tagNames) {
    return tagNames.indexOf(node.nodeName) >= 0;
  }
  function has(node, tagNames) {
    return node.getElementsByTagName && tagNames.some(function(tagName) {
      return node.getElementsByTagName(tagName).length;
    });
  }
  var markdownEscapes = [[/\\/g, "\\\\"], [/\*/g, "\\*"], [/^-/g, "\\-"], [/^\+ /g, "\\+ "], [/^(=+)/g, "\\$1"], [/^(#{1,6}) /g, "\\$1 "], [/`/g, "\\`"], [/^~~~/g, "\\~~~"], [/\[/g, "\\["], [/\]/g, "\\]"], [/^>/g, "\\>"], [/_/g, "\\_"], [/^(\d+)\. /g, "$1\\. "]];
  function escapeMarkdown(string) {
    return markdownEscapes.reduce(function(accumulator, escape) {
      return accumulator.replace(escape[0], escape[1]);
    }, string);
  }
  var rules = {};
  rules.paragraph = {
    filter: "p",
    replacement: function(content) {
      return "\n\n" + content + "\n\n";
    }
  };
  rules.lineBreak = {
    filter: "br",
    replacement: function(content, node, options) {
      return options.br + "\n";
    }
  };
  rules.heading = {
    filter: ["h1", "h2", "h3", "h4", "h5", "h6"],
    replacement: function(content, node, options) {
      var hLevel = Number(node.nodeName.charAt(1));
      if (options.headingStyle === "setext" && hLevel < 3) {
        var underline = repeat(hLevel === 1 ? "=" : "-", content.length);
        return "\n\n" + content + "\n" + underline + "\n\n";
      } else {
        return "\n\n" + repeat("#", hLevel) + " " + content + "\n\n";
      }
    }
  };
  rules.blockquote = {
    filter: "blockquote",
    replacement: function(content) {
      content = trimNewlines(content).replace(/^/gm, "> ");
      return "\n\n" + content + "\n\n";
    }
  };
  rules.list = {
    filter: ["ul", "ol"],
    replacement: function(content, node) {
      var parent = node.parentNode;
      if (parent.nodeName === "LI" && parent.lastElementChild === node) {
        return "\n" + content;
      } else {
        return "\n\n" + content + "\n\n";
      }
    }
  };
  rules.listItem = {
    filter: "li",
    replacement: function(content, node, options) {
      var prefix = options.bulletListMarker + "   ";
      var parent = node.parentNode;
      if (parent.nodeName === "OL") {
        var start = parent.getAttribute("start");
        var index = Array.prototype.indexOf.call(parent.children, node);
        prefix = (start ? Number(start) + index : index + 1) + ".  ";
      }
      var isParagraph = /\n$/.test(content);
      content = trimNewlines(content) + (isParagraph ? "\n" : "");
      content = content.replace(/\n/gm, "\n" + " ".repeat(prefix.length));
      return prefix + content + (node.nextSibling ? "\n" : "");
    }
  };
  rules.indentedCodeBlock = {
    filter: function(node, options) {
      return options.codeBlockStyle === "indented" && node.nodeName === "PRE" && node.firstChild && node.firstChild.nodeName === "CODE";
    },
    replacement: function(content, node, options) {
      return "\n\n    " + node.firstChild.textContent.replace(/\n/g, "\n    ") + "\n\n";
    }
  };
  rules.fencedCodeBlock = {
    filter: function(node, options) {
      return options.codeBlockStyle === "fenced" && node.nodeName === "PRE" && node.firstChild && node.firstChild.nodeName === "CODE";
    },
    replacement: function(content, node, options) {
      var className = node.firstChild.getAttribute("class") || "";
      var language = (className.match(/language-(\S+)/) || [null, ""])[1];
      var code = node.firstChild.textContent;
      var fenceChar = options.fence.charAt(0);
      var fenceSize = 3;
      var fenceInCodeRegex = new RegExp("^" + fenceChar + "{3,}", "gm");
      var match;
      while (match = fenceInCodeRegex.exec(code)) {
        if (match[0].length >= fenceSize) {
          fenceSize = match[0].length + 1;
        }
      }
      var fence = repeat(fenceChar, fenceSize);
      return "\n\n" + fence + language + "\n" + code.replace(/\n$/, "") + "\n" + fence + "\n\n";
    }
  };
  rules.horizontalRule = {
    filter: "hr",
    replacement: function(content, node, options) {
      return "\n\n" + options.hr + "\n\n";
    }
  };
  rules.inlineLink = {
    filter: function(node, options) {
      return options.linkStyle === "inlined" && node.nodeName === "A" && node.getAttribute("href");
    },
    replacement: function(content, node) {
      var href = escapeLinkDestination(node.getAttribute("href"));
      var title = escapeLinkTitle(cleanAttribute(node.getAttribute("title")));
      var titlePart = title ? ' "' + title + '"' : "";
      return "[" + content + "](" + href + titlePart + ")";
    }
  };
  rules.referenceLink = {
    filter: function(node, options) {
      return options.linkStyle === "referenced" && node.nodeName === "A" && node.getAttribute("href");
    },
    replacement: function(content, node, options) {
      var href = escapeLinkDestination(node.getAttribute("href"));
      var title = cleanAttribute(node.getAttribute("title"));
      if (title) title = ' "' + escapeLinkTitle(title) + '"';
      var replacement;
      var reference;
      switch (options.linkReferenceStyle) {
        case "collapsed":
          replacement = "[" + content + "][]";
          reference = "[" + content + "]: " + href + title;
          break;
        case "shortcut":
          replacement = "[" + content + "]";
          reference = "[" + content + "]: " + href + title;
          break;
        default:
          var id = this.references.length + 1;
          replacement = "[" + content + "][" + id + "]";
          reference = "[" + id + "]: " + href + title;
      }
      this.references.push(reference);
      return replacement;
    },
    references: [],
    append: function(options) {
      var references = "";
      if (this.references.length) {
        references = "\n\n" + this.references.join("\n") + "\n\n";
        this.references = [];
      }
      return references;
    }
  };
  rules.emphasis = {
    filter: ["em", "i"],
    replacement: function(content, node, options) {
      if (!content.trim()) return "";
      return options.emDelimiter + content + options.emDelimiter;
    }
  };
  rules.strong = {
    filter: ["strong", "b"],
    replacement: function(content, node, options) {
      if (!content.trim()) return "";
      return options.strongDelimiter + content + options.strongDelimiter;
    }
  };
  rules.code = {
    filter: function(node) {
      var hasSiblings = node.previousSibling || node.nextSibling;
      var isCodeBlock = node.parentNode.nodeName === "PRE" && !hasSiblings;
      return node.nodeName === "CODE" && !isCodeBlock;
    },
    replacement: function(content) {
      if (!content) return "";
      content = content.replace(/\r?\n|\r/g, " ");
      var extraSpace = /^`|^ .*?[^ ].* $|`$/.test(content) ? " " : "";
      var delimiter = "`";
      var matches = content.match(/`+/gm) || [];
      while (matches.indexOf(delimiter) !== -1) delimiter = delimiter + "`";
      return delimiter + extraSpace + content + extraSpace + delimiter;
    }
  };
  rules.image = {
    filter: "img",
    replacement: function(content, node) {
      var alt = escapeMarkdown(cleanAttribute(node.getAttribute("alt")));
      var src = escapeLinkDestination(node.getAttribute("src") || "");
      var title = cleanAttribute(node.getAttribute("title"));
      var titlePart = title ? ' "' + escapeLinkTitle(title) + '"' : "";
      return src ? "![" + alt + "](" + src + titlePart + ")" : "";
    }
  };
  function cleanAttribute(attribute) {
    return attribute ? attribute.replace(/(\n+\s*)+/g, "\n") : "";
  }
  function escapeLinkDestination(destination) {
    var escaped = destination.replace(/([<>()])/g, "\\$1");
    return escaped.indexOf(" ") >= 0 ? "<" + escaped + ">" : escaped;
  }
  function escapeLinkTitle(title) {
    return title.replace(/"/g, '\\"');
  }
  function Rules(options) {
    this.options = options;
    this._keep = [];
    this._remove = [];
    this.blankRule = {
      replacement: options.blankReplacement
    };
    this.keepReplacement = options.keepReplacement;
    this.defaultRule = {
      replacement: options.defaultReplacement
    };
    this.array = [];
    for (var key in options.rules) this.array.push(options.rules[key]);
  }
  Rules.prototype = {
    add: function(key, rule) {
      this.array.unshift(rule);
    },
    keep: function(filter) {
      this._keep.unshift({
        filter,
        replacement: this.keepReplacement
      });
    },
    remove: function(filter) {
      this._remove.unshift({
        filter,
        replacement: function() {
          return "";
        }
      });
    },
    forNode: function(node) {
      if (node.isBlank) return this.blankRule;
      var rule;
      if (rule = findRule(this.array, node, this.options)) return rule;
      if (rule = findRule(this._keep, node, this.options)) return rule;
      if (rule = findRule(this._remove, node, this.options)) return rule;
      return this.defaultRule;
    },
    forEach: function(fn) {
      for (var i = 0; i < this.array.length; i++) fn(this.array[i], i);
    }
  };
  function findRule(rules3, node, options) {
    for (var i = 0; i < rules3.length; i++) {
      var rule = rules3[i];
      if (filterValue(rule, node, options)) return rule;
    }
    return void 0;
  }
  function filterValue(rule, node, options) {
    var filter = rule.filter;
    if (typeof filter === "string") {
      if (filter === node.nodeName.toLowerCase()) return true;
    } else if (Array.isArray(filter)) {
      if (filter.indexOf(node.nodeName.toLowerCase()) > -1) return true;
    } else if (typeof filter === "function") {
      if (filter.call(rule, node, options)) return true;
    } else {
      throw new TypeError("`filter` needs to be a string, array, or function");
    }
  }
  function collapseWhitespace(options) {
    var element = options.element;
    var isBlock2 = options.isBlock;
    var isVoid2 = options.isVoid;
    var isPre = options.isPre || function(node2) {
      return node2.nodeName === "PRE";
    };
    if (!element.firstChild || isPre(element)) return;
    var prevText = null;
    var keepLeadingWs = false;
    var prev = null;
    var node = next(prev, element, isPre);
    while (node !== element) {
      if (node.nodeType === 3 || node.nodeType === 4) {
        var text = node.data.replace(/[ \r\n\t]+/g, " ");
        if ((!prevText || / $/.test(prevText.data)) && !keepLeadingWs && text[0] === " ") {
          text = text.substr(1);
        }
        if (!text) {
          node = remove(node);
          continue;
        }
        node.data = text;
        prevText = node;
      } else if (node.nodeType === 1) {
        if (isBlock2(node) || node.nodeName === "BR") {
          if (prevText) {
            prevText.data = prevText.data.replace(/ $/, "");
          }
          prevText = null;
          keepLeadingWs = false;
        } else if (isVoid2(node) || isPre(node)) {
          prevText = null;
          keepLeadingWs = true;
        } else if (prevText) {
          keepLeadingWs = false;
        }
      } else {
        node = remove(node);
        continue;
      }
      var nextNode = next(prev, node, isPre);
      prev = node;
      node = nextNode;
    }
    if (prevText) {
      prevText.data = prevText.data.replace(/ $/, "");
      if (!prevText.data) {
        remove(prevText);
      }
    }
  }
  function remove(node) {
    var next2 = node.nextSibling || node.parentNode;
    node.parentNode.removeChild(node);
    return next2;
  }
  function next(prev, current, isPre) {
    if (prev && prev.parentNode === current || isPre(current)) {
      return current.nextSibling || current.parentNode;
    }
    return current.firstChild || current.nextSibling || current.parentNode;
  }
  var root = typeof window !== "undefined" ? window : {};
  function canParseHTMLNatively() {
    var Parser = root.DOMParser;
    var canParse = false;
    try {
      if (new Parser().parseFromString("", "text/html")) {
        canParse = true;
      }
    } catch (e) {
    }
    return canParse;
  }
  function createHTMLParser() {
    var Parser = function() {
    };
    {
      if (shouldUseActiveX()) {
        Parser.prototype.parseFromString = function(string) {
          var doc = new window.ActiveXObject("htmlfile");
          doc.designMode = "on";
          doc.open();
          doc.write(string);
          doc.close();
          return doc;
        };
      } else {
        Parser.prototype.parseFromString = function(string) {
          var doc = document.implementation.createHTMLDocument("");
          doc.open();
          doc.write(string);
          doc.close();
          return doc;
        };
      }
    }
    return Parser;
  }
  function shouldUseActiveX() {
    var useActiveX = false;
    try {
      document.implementation.createHTMLDocument("").open();
    } catch (e) {
      if (root.ActiveXObject) useActiveX = true;
    }
    return useActiveX;
  }
  var HTMLParser = canParseHTMLNatively() ? root.DOMParser : createHTMLParser();
  function RootNode(input, options) {
    var root2;
    if (typeof input === "string") {
      var doc = htmlParser().parseFromString(
        // DOM parsers arrange elements in the <head> and <body>.
        // Wrapping in a custom element ensures elements are reliably arranged in
        // a single element.
        '<x-turndown id="turndown-root">' + input + "</x-turndown>",
        "text/html"
      );
      root2 = doc.getElementById("turndown-root");
    } else {
      root2 = input.cloneNode(true);
    }
    collapseWhitespace({
      element: root2,
      isBlock,
      isVoid,
      isPre: options.preformattedCode ? isPreOrCode : null
    });
    return root2;
  }
  var _htmlParser;
  function htmlParser() {
    _htmlParser = _htmlParser || new HTMLParser();
    return _htmlParser;
  }
  function isPreOrCode(node) {
    return node.nodeName === "PRE" || node.nodeName === "CODE";
  }
  function Node(node, options) {
    node.isBlock = isBlock(node);
    node.isCode = node.nodeName === "CODE" || node.parentNode.isCode;
    node.isBlank = isBlank(node);
    node.flankingWhitespace = flankingWhitespace(node, options);
    return node;
  }
  function isBlank(node) {
    return !isVoid(node) && !isMeaningfulWhenBlank(node) && /^\s*$/i.test(node.textContent) && !hasVoid(node) && !hasMeaningfulWhenBlank(node);
  }
  function flankingWhitespace(node, options) {
    if (node.isBlock || options.preformattedCode && node.isCode) {
      return {
        leading: "",
        trailing: ""
      };
    }
    var edges = edgeWhitespace(node.textContent);
    if (edges.leadingAscii && isFlankedByWhitespace("left", node, options)) {
      edges.leading = edges.leadingNonAscii;
    }
    if (edges.trailingAscii && isFlankedByWhitespace("right", node, options)) {
      edges.trailing = edges.trailingNonAscii;
    }
    return {
      leading: edges.leading,
      trailing: edges.trailing
    };
  }
  function edgeWhitespace(string) {
    var m = string.match(/^(([ \t\r\n]*)(\s*))(?:(?=\S)[\s\S]*\S)?((\s*?)([ \t\r\n]*))$/);
    return {
      leading: m[1],
      // whole string for whitespace-only strings
      leadingAscii: m[2],
      leadingNonAscii: m[3],
      trailing: m[4],
      // empty for whitespace-only strings
      trailingNonAscii: m[5],
      trailingAscii: m[6]
    };
  }
  function isFlankedByWhitespace(side, node, options) {
    var sibling;
    var regExp;
    var isFlanked;
    if (side === "left") {
      sibling = node.previousSibling;
      regExp = / $/;
    } else {
      sibling = node.nextSibling;
      regExp = /^ /;
    }
    if (sibling) {
      if (sibling.nodeType === 3) {
        isFlanked = regExp.test(sibling.nodeValue);
      } else if (options.preformattedCode && sibling.nodeName === "CODE") {
        isFlanked = false;
      } else if (sibling.nodeType === 1 && !isBlock(sibling)) {
        isFlanked = regExp.test(sibling.textContent);
      }
    }
    return isFlanked;
  }
  var reduce = Array.prototype.reduce;
  function TurndownService(options) {
    if (!(this instanceof TurndownService)) return new TurndownService(options);
    var defaults = {
      rules,
      headingStyle: "setext",
      hr: "* * *",
      bulletListMarker: "*",
      codeBlockStyle: "indented",
      fence: "```",
      emDelimiter: "_",
      strongDelimiter: "**",
      linkStyle: "inlined",
      linkReferenceStyle: "full",
      br: "  ",
      preformattedCode: false,
      blankReplacement: function(content, node) {
        return node.isBlock ? "\n\n" : "";
      },
      keepReplacement: function(content, node) {
        return node.isBlock ? "\n\n" + node.outerHTML + "\n\n" : node.outerHTML;
      },
      defaultReplacement: function(content, node) {
        return node.isBlock ? "\n\n" + content + "\n\n" : content;
      }
    };
    this.options = extend({}, defaults, options);
    this.rules = new Rules(this.options);
  }
  TurndownService.prototype = {
    /**
     * The entry point for converting a string or DOM node to Markdown
     * @public
     * @param {String|HTMLElement} input The string or DOM node to convert
     * @returns A Markdown representation of the input
     * @type String
     */
    turndown: function(input) {
      if (!canConvert(input)) {
        throw new TypeError(input + " is not a string, or an element/document/fragment node.");
      }
      if (input === "") return "";
      var output = process.call(this, new RootNode(input, this.options));
      return postProcess.call(this, output);
    },
    /**
     * Add one or more plugins
     * @public
     * @param {Function|Array} plugin The plugin or array of plugins to add
     * @returns The Turndown instance for chaining
     * @type Object
     */
    use: function(plugin) {
      if (Array.isArray(plugin)) {
        for (var i = 0; i < plugin.length; i++) this.use(plugin[i]);
      } else if (typeof plugin === "function") {
        plugin(this);
      } else {
        throw new TypeError("plugin must be a Function or an Array of Functions");
      }
      return this;
    },
    /**
     * Adds a rule
     * @public
     * @param {String} key The unique key of the rule
     * @param {Object} rule The rule
     * @returns The Turndown instance for chaining
     * @type Object
     */
    addRule: function(key, rule) {
      this.rules.add(key, rule);
      return this;
    },
    /**
     * Keep a node (as HTML) that matches the filter
     * @public
     * @param {String|Array|Function} filter The unique key of the rule
     * @returns The Turndown instance for chaining
     * @type Object
     */
    keep: function(filter) {
      this.rules.keep(filter);
      return this;
    },
    /**
     * Remove a node that matches the filter
     * @public
     * @param {String|Array|Function} filter The unique key of the rule
     * @returns The Turndown instance for chaining
     * @type Object
     */
    remove: function(filter) {
      this.rules.remove(filter);
      return this;
    },
    /**
     * Escapes Markdown syntax
     * @public
     * @param {String} string The string to escape
     * @returns A string with Markdown syntax escaped
     * @type String
     */
    escape: function(string) {
      return escapeMarkdown(string);
    }
  };
  function process(parentNode) {
    var self = this;
    return reduce.call(parentNode.childNodes, function(output, node) {
      node = new Node(node, self.options);
      var replacement = "";
      if (node.nodeType === 3) {
        replacement = node.isCode ? node.nodeValue : self.escape(node.nodeValue);
      } else if (node.nodeType === 1) {
        replacement = replacementForNode.call(self, node);
      }
      join(output, replacement);
      return output;
    }, []);
  }
  function postProcess(output) {
    var self = this;
    this.rules.forEach(function(rule) {
      if (typeof rule.append === "function") {
        join(output, rule.append(self.options));
      }
    });
    return output.join("").replace(/^[\t\r\n]+/, "").replace(/[\t\r\n\s]+$/, "");
  }
  function replacementForNode(node) {
    var rule = this.rules.forNode(node);
    var content = process.call(this, node).join("");
    var whitespace = node.flankingWhitespace;
    if (whitespace.leading || whitespace.trailing) content = content.trim();
    return whitespace.leading + rule.replacement(content, node, this.options) + whitespace.trailing;
  }
  function join(output, replacement) {
    var tail = output.pop() || "";
    var s1 = trimTrailingNewlines(tail);
    var s2 = trimLeadingNewlines(replacement);
    var nls = Math.max(tail.length - s1.length, replacement.length - s2.length);
    var separator = "\n\n".substring(0, nls);
    if (s1) output.push(s1);
    if (separator) output.push(separator);
    if (s2) output.push(s2);
  }
  function canConvert(input) {
    return input != null && (typeof input === "string" || input.nodeType && (input.nodeType === 1 || input.nodeType === 9 || input.nodeType === 11));
  }

  // node_modules/turndown-plugin-gfm/lib/turndown-plugin-gfm.es.js
  var indexOf = Array.prototype.indexOf;
  var every = Array.prototype.every;
  var rules2 = {};
  rules2.tableCell = {
    filter: ["th", "td"],
    replacement: function(content, node) {
      return cell(content, node);
    }
  };
  rules2.tableRow = {
    filter: "tr",
    replacement: function(content, node) {
      var borderCells = "";
      var alignMap = { left: ":--", right: "--:", center: ":-:" };
      if (isHeadingRow(node)) {
        for (var i = 0; i < node.childNodes.length; i++) {
          var border = "---";
          var align = (node.childNodes[i].getAttribute("align") || "").toLowerCase();
          if (align) border = alignMap[align] || border;
          borderCells += cell(border, node.childNodes[i]);
        }
      }
      return "\n" + content + (borderCells ? "\n" + borderCells : "");
    }
  };
  rules2.table = {
    // Only convert tables with a heading row.
    // Tables with no heading row are kept using `keep` (see below).
    filter: function(node) {
      return node.nodeName === "TABLE" && isHeadingRow(node.rows[0]);
    },
    replacement: function(content) {
      content = content.replace("\n\n", "\n");
      return "\n\n" + content + "\n\n";
    }
  };
  rules2.tableSection = {
    filter: ["thead", "tbody", "tfoot"],
    replacement: function(content) {
      return content;
    }
  };
  function isHeadingRow(tr) {
    var parentNode = tr.parentNode;
    return parentNode.nodeName === "THEAD" || parentNode.firstChild === tr && (parentNode.nodeName === "TABLE" || isFirstTbody(parentNode)) && every.call(tr.childNodes, function(n) {
      return n.nodeName === "TH";
    });
  }
  function isFirstTbody(element) {
    var previousSibling = element.previousSibling;
    return element.nodeName === "TBODY" && (!previousSibling || previousSibling.nodeName === "THEAD" && /^\s*$/i.test(previousSibling.textContent));
  }
  function cell(content, node) {
    var index = indexOf.call(node.parentNode.childNodes, node);
    var prefix = " ";
    if (index === 0) prefix = "| ";
    return prefix + content + " |";
  }

  // core/images/images.ts
  var IMAGE_LIMITS = Object.freeze({
    imageBytes: 10 * 1024 * 1024,
    totalBytes: 50 * 1024 * 1024,
    timeoutMs: 1e4
  });

  // core/notion/notion-page.ts
  function notionPageId(value) {
    let candidate = value.trim();
    if (/^https?:/i.test(candidate)) {
      const url = new URL(candidate);
      if (url.protocol !== "https:" || url.hostname !== "app.notion.com") {
        throw failure("notionInvalidParent");
      }
      candidate = url.pathname.split("/").filter(Boolean).at(-1) ?? "";
    }
    const match = candidate.match(
      /(?:^|-)([a-f0-9]{32}|[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12})$/i
    );
    if (!match) {
      throw failure("notionInvalidParent");
    }
    return match[1].replaceAll("-", "");
  }

  // core/notion/token.ts
  function normalizeToken(token) {
    return token.trim().replace(/^Bearer\s+/i, "").replace(/\s/g, "");
  }

  // core/notion/notion.ts
  async function notionRequest(token, path, body, fetcher, options = {}) {
    const multipart = body instanceof FormData;
    const method = options.method ?? (path.endsWith("/markdown") ? "PATCH" : "POST");
    const sleep = options.sleep;
    for (let attempt = 0; ; attempt++) {
      let response;
      let result;
      try {
        response = await fetcher(`https://api.notion.com/v1/${path}`, {
          method,
          headers: {
            Authorization: `Bearer ${token}`,
            "Notion-Version": "2026-03-11",
            ...multipart ? {} : { "Content-Type": "application/json" }
          },
          ...body === void 0 ? {} : { body: multipart ? body : JSON.stringify(body) },
          signal: AbortSignal.timeout(6e4),
          redirect: "error"
        });
        result = await response.json();
      } catch {
        throw Object.assign(failure("notionSaveError"), { ambiguous: method !== "GET" });
      }
      if ([429, 529].includes(response.status ?? 0) && result.additional_data?.rate_limit_reason !== "public_api_request_blocked" && attempt < 3) {
        const retry = response.headers?.get("retry-after");
        const seconds = retry !== null && retry !== void 0 && Number.isFinite(Number(retry)) ? Math.max(0, Number(retry)) : 2 ** attempt;
        await sleep(seconds * 1e3);
        continue;
      }
      if (!response.ok) {
        const committedId = result.additional_data?.committed_resource_id;
        if (response.status === 503 && path === "pages" && /^[a-f0-9-]{32,36}$/i.test(committedId ?? "")) {
          return { id: committedId };
        }
        const keys = {
          401: "notionUnauthorized",
          403: "notionForbidden",
          404: "notionNotFound",
          429: "notionRateLimited",
          529: "notionRateLimited"
        };
        throw Object.assign(failure(keys[response.status ?? 0] ?? "notionSaveError"), {
          status: response.status,
          ambiguous: (response.status ?? 0) >= 500 && response.status !== 529
        });
      }
      return result;
    }
  }
  async function uploadNotionImage(token, image, fetcher, options = {}) {
    const extensions = {
      "image/png": "png",
      "image/jpeg": "jpg",
      "image/gif": "gif",
      "image/webp": "webp",
      "image/svg+xml": "svg",
      "image/heic": "heic",
      "image/tiff": "tiff",
      "image/vnd.microsoft.icon": "ico",
      "image/bmp": "bmp",
      "image/avif": "avif",
      "image/apng": "apng"
    };
    const extension = extensions[image.type ?? ""];
    if (!extension) {
      throw Object.assign(failure("notionImageFormat"), { imageReason: "format" });
    }
    const filename = `image.${extension}`;
    const upload = await notionRequest(
      token,
      "file_uploads",
      { mode: "single_part", filename, content_type: image.type },
      fetcher,
      options
    );
    const form = new FormData();
    form.append("file", new Blob([new Uint8Array(image.bytes)], { type: image.type }), filename);
    const sent = await notionRequest(token, `file_uploads/${upload.id}/send`, form, fetcher, options);
    if (sent.status !== "uploaded") {
      throw failure("notionSaveError");
    }
    return upload.id;
  }
  async function notionChildren(token, blockId, fetcher, options = {}) {
    const blocks = [];
    let cursor;
    do {
      const query = cursor ? `?start_cursor=${encodeURIComponent(cursor)}` : "";
      const result = await notionRequest(
        token,
        `blocks/${blockId}/children${query}`,
        void 0,
        fetcher,
        { ...options, method: "GET" }
      );
      blocks.push(...result.results);
      cursor = result.has_more ? result.next_cursor : void 0;
    } while (cursor);
    return blocks;
  }
  async function createNotionPage(token, parentId, title, fetcher, options = {}) {
    return notionRequest(
      token,
      "pages",
      {
        parent: { type: "page_id", page_id: notionPageId(parentId) },
        properties: {
          title: {
            type: "title",
            title: [{ type: "text", text: { content: title.slice(0, 2e3) } }]
          }
        }
      },
      fetcher,
      options
    );
  }
  async function writeNotionMarkdown(token, pageId, markdown, fetcher, options = {}) {
    return notionRequest(
      token,
      `pages/${pageId}/markdown`,
      {
        type: "replace_content",
        replace_content: { new_str: markdown }
      },
      fetcher,
      options
    );
  }
  var rich = (text, bold = false) => Array.from({ length: Math.ceil(text.length / 2e3) }, (_, index) => ({
    type: "text",
    text: { content: text.slice(index * 2e3, (index + 1) * 2e3) },
    annotations: { bold }
  }));
  function createNotionApi({
    token,
    fetcher,
    sleep
  }) {
    if (typeof fetcher !== "function" || typeof sleep !== "function") {
      throw new TypeError("createNotionApi requires fetcher and sleep functions");
    }
    const request = (path, body, options = {}) => notionRequest(token, path, body, fetcher, { ...options, sleep });
    const patch = (id, body) => request(`blocks/${id}`, body, { method: "PATCH" });
    return {
      createPage: (parentId, title) => createNotionPage(token, parentId, title, fetcher, { sleep }),
      writeMarkdown: (pageId, markdown) => writeNotionMarkdown(token, pageId, markdown, fetcher, { sleep }),
      children: (id) => notionChildren(token, id, fetcher, { sleep }),
      uploadImage: (image) => uploadNotionImage(token, image, fetcher, { sleep }),
      async appendImage({ targetId, markerId, uploadId, marker, container }) {
        const result = await request(
          `blocks/${targetId}/children`,
          {
            children: [
              {
                object: "block",
                type: "image",
                image: { type: "file_upload", file_upload: { id: uploadId }, caption: rich(marker) }
              }
            ],
            position: container ? { type: "start" } : { type: "after_block", after_block: { id: markerId } }
          },
          { method: "PATCH" }
        );
        return result.results?.[0]?.id;
      },
      setCaption: (id, alt) => patch(id, { image: { caption: rich(alt.slice(0, 2e3)) } }),
      clearMarker: (id, type) => patch(id, { [type]: { rich_text: [] } }),
      removeBlock: (id) => request(`blocks/${id}`, void 0, { method: "DELETE" }),
      writeImageError: (id, type, text) => patch(id, { [type]: { rich_text: rich(text, true) } })
    };
  }

  // core/notion/notion-export.ts
  var blockText = (block) => (block[block.type]?.rich_text ?? block.image?.caption ?? []).map((item) => item.plain_text ?? item.text?.content ?? "").join("");
  var fatal = (error) => [401, 403, 404].includes(errorDetails(error).status ?? 0);
  async function findMarkers(api, pageId, state) {
    const wanted = new Map(
      state.occurrences.filter((item) => item.status !== "complete" && !item.blockId).map((item) => [item.marker, item])
    );
    async function visit(parentId) {
      const children = await api.children(parentId);
      for (const block of children) {
        const item = wanted.get(blockText(block));
        if (item && [
          "paragraph",
          "bulleted_list_item",
          "numbered_list_item",
          "quote",
          "heading_1",
          "heading_2",
          "heading_3"
        ].includes(block.type)) {
          item.blockId = block.id;
          item.blockType = block.type;
          item.container = Boolean(block.has_children) || ["bulleted_list_item", "numbered_list_item", "quote"].includes(block.type);
          item.parentId = parentId;
          wanted.delete(item.marker);
        }
        if (block.has_children && wanted.size) {
          await visit(block.id);
        }
      }
    }
    await visit(pageId);
    if (wanted.size) {
      throw failure("notionImageUncertain");
    }
  }
  async function attachImage(api, item, uploadId, checkpoint) {
    const targetId = item.container ? item.blockId : item.parentId;
    if (item.insertion === "uncertain") {
      const children = await api.children(targetId);
      const index = item.container ? -1 : children.findIndex((block) => block.id === item.blockId);
      const next2 = children[index + 1];
      if (!item.container && index < 0 || next2?.type !== "image" || blockText(next2) !== item.marker) {
        throw failure("notionImageUncertain");
      }
      item.insertedId = next2.id;
      item.insertion = "confirmed";
      await checkpoint();
    }
    if (!item.insertedId) {
      item.insertion = "uncertain";
      await checkpoint();
      try {
        item.insertedId = await api.appendImage({
          targetId,
          markerId: item.blockId,
          uploadId,
          marker: item.marker,
          container: item.container
        });
        item.insertion = "confirmed";
        if (!item.insertedId) {
          throw Object.assign(failure("notionImageUncertain"), { ambiguous: true });
        }
      } catch (caught) {
        const error = errorDetails(caught);
        if (error.ambiguous) {
          item.insertion = "uncertain";
          return attachImage(api, item, uploadId, checkpoint);
        }
        item.insertion = "pending";
        await checkpoint();
        throw error;
      }
      await checkpoint();
    }
    await checkpoint();
    await api.setCaption(item.insertedId, item.alt);
    await checkpoint();
    if (item.container) {
      await checkpoint();
      await api.clearMarker(item.blockId, item.blockType);
      await checkpoint();
    } else {
      if (item.cleanup === "uncertain") {
        const children = await api.children(item.parentId);
        if (!children.some((block) => block.id === item.blockId)) {
          return;
        }
      }
      item.cleanup = "uncertain";
      await checkpoint();
      try {
        await api.removeBlock(item.blockId);
      } catch (caught) {
        const error = errorDetails(caught);
        item.cleanup = "uncertain";
        throw error;
      }
    }
  }
  async function exportNotionArticle({
    state,
    api,
    parentId,
    title,
    downloadImages,
    formatImageError,
    progress = () => {
    },
    onPage = () => {
    },
    checkpoint = async () => {
    }
  }) {
    if (state.creation === "uncertain") {
      throw failure("notionImageUncertain");
    }
    if (!state.page) {
      state.creation = "uncertain";
      await checkpoint();
      try {
        state.page = await api.createPage(parentId, title);
        state.creation = "confirmed";
      } catch (caught) {
        const error = errorDetails(caught);
        state.creation = error.ambiguous ? "uncertain" : "pending";
        await checkpoint();
        throw error;
      }
      await checkpoint();
    }
    onPage(state.page);
    if (state.downloading !== "confirmed") {
      const urls = [...new Set(state.occurrences.map((item) => item.url))];
      const images = await downloadImages(
        urls,
        (count2) => progress({ stage: "download", completed: count2, total: urls.length })
      );
      for (const url of urls) {
        const image = images.find((item) => item.url === url) ?? {
          url,
          failed: true,
          reason: "network"
        };
        state.assets.set(url, { image });
      }
      state.downloading = "confirmed";
      await checkpoint();
    }
    if (state.writing !== "confirmed") {
      if (state.writing === "uncertain") {
        if (!state.occurrences.length) {
          throw failure("notionImageUncertain");
        }
        await findMarkers(api, state.page.id, state);
      } else {
        state.writing = "uncertain";
        await checkpoint();
        try {
          await api.writeMarkdown(state.page.id, state.markdown);
        } catch (caught) {
          const error = errorDetails(caught);
          state.writing = error.ambiguous ? "uncertain" : "pending";
          await checkpoint();
          throw error;
        }
      }
      state.writing = "confirmed";
      await checkpoint();
    }
    if (!state.occurrences.length) {
      return state;
    }
    await findMarkers(api, state.page.id, state);
    let count = 0;
    for (const asset of state.assets.values()) {
      progress({ stage: "upload", completed: count, total: state.assets.size });
      if (!asset.uploadId && !asset.error && asset.image.failed) {
        asset.error = { reason: asset.image.reason ?? "network", status: asset.image.status };
      }
      if (!asset.uploadId && !asset.error) {
        if (asset.uploading === "uncertain") {
          throw failure("notionImageUncertain");
        }
        asset.uploading = "uncertain";
        await checkpoint();
        try {
          asset.uploadId = await api.uploadImage(asset.image);
          asset.uploading = "confirmed";
        } catch (caught) {
          const error = errorDetails(caught);
          if (fatal(error) || error.ambiguous) {
            if (!error.ambiguous) {
              asset.uploading = "pending";
            }
            await checkpoint();
            throw error;
          }
          asset.uploading = "pending";
          asset.error = { reason: error.imageReason ?? "upload" };
        }
        await checkpoint();
      }
      count++;
      progress({ stage: "upload", completed: count, total: state.assets.size });
    }
    progress({ stage: "finish", completed: 0, total: 0 });
    for (const item of state.occurrences) {
      if (item.status === "complete") {
        continue;
      }
      const asset = state.assets.get(item.url);
      if (!asset.error && !item.error) {
        try {
          await attachImage(api, item, asset.uploadId, checkpoint);
        } catch (caught) {
          const error = errorDetails(caught);
          if (error.ambiguous || item.insertion === "uncertain" || item.insertedId || fatal(error) || error.message === "notionImageUncertain") {
            throw error;
          }
          item.error = { reason: error.status === 400 ? "location" : "upload" };
        }
      }
      if (asset.error || item.error) {
        await checkpoint();
        await api.writeImageError(
          item.blockId,
          item.blockType,
          formatImageError(asset.error ?? item.error)
        );
        state.failedCount++;
      }
      item.cleanup = "confirmed";
      item.status = "complete";
      await checkpoint();
    }
    return state;
  }

  // extension/integrations/integrations.ts
  var LOCK_NAME = "html2md-integrations";
  var tokenKey = (id) => `integrationToken:${id}`;
  var persisted = ({ id, type, name, parentId, rememberToken }) => ({
    id,
    type,
    name,
    parentId,
    rememberToken: rememberToken ?? false
  });
  function createIntegrationRepository({
    storage,
    locks,
    createId
  }) {
    let initialization;
    let ready = false;
    async function safe(action) {
      try {
        return await action();
      } catch (caught) {
        const error = errorDetails(caught);
        if ([
          "integrationNotFound",
          "integrationNameRequired",
          "notionInvalidParent",
          "notionMissingToken"
        ].includes(error.message ?? "")) {
          throw error;
        }
        throw failure("notionSettingsError");
      }
    }
    const locked = (action) => safe(() => locks.request(LOCK_NAME, action));
    async function initialize() {
      initialization ??= locked(async () => {
        await Promise.all([
          storage.local.setAccessLevel({ accessLevel: "TRUSTED_CONTEXTS" }),
          storage.session.setAccessLevel({ accessLevel: "TRUSTED_CONTEXTS" })
        ]);
        const local = await storage.local.get(["integrations", "notion", "notionParentId"]);
        if (!local.integrations) {
          const session = await storage.session.get(["notionToken", tokenKey("legacy-notion")]);
          const token = session.notionToken || local.notion?.token;
          const parentId = local.notionParentId || local.notion?.parentId || "";
          if (token && !session[tokenKey("legacy-notion")]) {
            await storage.session.set({ [tokenKey("legacy-notion")]: token });
          }
          await storage.local.set({
            integrations: parentId || token ? [{ id: "legacy-notion", type: "notion", name: "Notion", parentId }] : []
          });
        }
        await storage.local.remove("notion");
        await storage.local.remove("notionParentId");
        await storage.session.remove("notionToken");
        ready = true;
      });
      try {
        await initialization;
      } catch (caught) {
        const error = errorDetails(caught);
        initialization = void 0;
        throw error;
      }
    }
    async function records() {
      if (!ready) {
        throw failure("notionSettingsError");
      }
      return (await storage.local.get("integrations")).integrations ?? [];
    }
    const tokenStorage = (record) => storage[record?.rememberToken ? "local" : "session"];
    const readToken = async (record) => (await tokenStorage(record).get(tokenKey(record.id)))[tokenKey(record.id)];
    const writeToken = (area, key, value) => value === void 0 ? area.remove(key) : area.set({ [key]: value });
    async function clearTokens(key) {
      await storage.local.remove(key);
      await storage.session.remove(key);
    }
    async function list() {
      return locked(
        async () => Promise.all(
          (await records()).map(async (record) => ({
            ...persisted(record),
            connected: Boolean(await readToken(record))
          }))
        )
      );
    }
    async function connection(id) {
      return locked(async () => {
        const record = (await records()).find((item) => item.id === id);
        if (!record) {
          throw failure("integrationNotFound");
        }
        return { ...persisted(record), token: await readToken(record) ?? "" };
      });
    }
    async function changeTokens(id, action) {
      const key = tokenKey(id);
      const local = (await storage.local.get(key))[key];
      const session = (await storage.session.get(key))[key];
      try {
        await action(key);
      } catch (error) {
        const restored = await Promise.allSettled([
          writeToken(storage.local, key, local),
          writeToken(storage.session, key, session)
        ]);
        if (restored.some((result) => result.status === "rejected")) {
          throw failure("notionSettingsError");
        }
        throw error;
      }
    }
    async function save({ id, name, parentId, token, rememberToken }) {
      return locked(async () => {
        const parent = notionPageId(parentId);
        if (!name.trim()) {
          throw failure("integrationNameRequired");
        }
        const current = await records();
        const index = current.findIndex((item) => item.id === id);
        if (id && index < 0) {
          throw failure("integrationNotFound");
        }
        const normalized = normalizeToken(token);
        if (!normalized && !id) {
          throw failure("notionMissingToken");
        }
        const previous = current[index];
        const record = {
          id: id ?? createId(),
          type: "notion",
          name: name.trim(),
          parentId: parent,
          rememberToken: rememberToken ?? previous?.rememberToken ?? false
        };
        const next2 = current.map(persisted);
        if (index < 0) {
          next2.push(record);
        } else {
          next2[index] = record;
        }
        await changeTokens(record.id, async (key) => {
          const value = normalized || (previous ? await readToken(previous) : void 0);
          await writeToken(tokenStorage(record), key, value);
          await storage[record.rememberToken ? "session" : "local"].remove(key);
          await storage.local.set({ integrations: next2 });
        });
        return record.id;
      });
    }
    async function forgetToken(id) {
      return locked(async () => {
        if (!(await records()).some((record) => record.id === id)) {
          throw failure("integrationNotFound");
        }
        await changeTokens(id, clearTokens);
      });
    }
    async function remove2(id) {
      return locked(async () => {
        const current = await records();
        await changeTokens(id, async (key) => {
          await clearTokens(key);
          await storage.local.set({
            integrations: current.filter((item) => item.id !== id).map(persisted)
          });
        });
      });
    }
    return { initialize, list, connection, save, remove: remove2, forgetToken };
  }

  // extension/integrations/commands.ts
  var INTEGRATION_CHANNEL = "html2md-integrations";
  var integrationErrorCodes = [
    "notionSettingsError",
    "integrationNotFound",
    "integrationNameRequired",
    "notionInvalidParent",
    "notionMissingToken"
  ];

  // extension/background/integration-handler.ts
  function validInput(input) {
    if (!input || typeof input !== "object") {
      return false;
    }
    const value = input;
    return ["name", "parentId", "token"].every((key) => typeof value[key] === "string") && (value.id === void 0 || typeof value.id === "string" && value.id.length > 0) && (value.rememberToken === void 0 || typeof value.rememberToken === "boolean");
  }
  function createIntegrationHandler(repository2, runtime) {
    async function execute(message, sender) {
      const url = sender.url?.split(/[?#]/)[0];
      const options = url === runtime.getURL("options.html");
      const panel = url === runtime.getURL("side-panel.html");
      if (sender.id !== runtime.id || !options && !panel) {
        throw failure("notionSettingsError");
      }
      switch (message.type) {
        case "initialize":
          await repository2.initialize();
          return;
        case "list":
          await repository2.initialize();
          return repository2.list();
        case "save":
          if (!options || !validInput(message.input)) {
            throw failure("notionSettingsError");
          }
          await repository2.initialize();
          return repository2.save(message.input);
        case "remove":
        case "forget":
          if (!options || typeof message.id !== "string" || !message.id) {
            throw failure("notionSettingsError");
          }
          await repository2.initialize();
          await (message.type === "remove" ? repository2.remove(message.id) : repository2.forgetToken(message.id));
          return;
        default:
          throw failure("notionSettingsError");
      }
    }
    return function onMessage(message, sender, respond) {
      if (!message || typeof message !== "object" || message.channel !== INTEGRATION_CHANNEL) {
        return;
      }
      void execute(message, sender).then(
        (value) => respond({ ok: true, value }),
        (caught) => {
          const code = errorDetails(caught).code;
          respond({
            ok: false,
            code: integrationErrorCodes.find((known) => known === code) ?? "notionSettingsError"
          });
        }
      );
      return true;
    };
  }

  // extension/browser/notion-client.ts
  var NOTION_CHANNEL = "html2md-notion";
  var notionErrorCodes = [
    "notionSettingsError",
    "integrationNotFound",
    "notionMissingToken",
    "notionInvalidParent",
    "notionUnauthorized",
    "notionForbidden",
    "notionNotFound",
    "notionRateLimited",
    "notionSaveError",
    "notionImageFormat",
    "notionImageUncertain"
  ];

  // extension/background/notion-handler.ts
  var isId = (value) => typeof value === "string" && /^(?:[a-f0-9]{32}|[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12})$/i.test(value);
  var isText = (value) => typeof value === "string";
  var isBlockType = (value) => typeof value === "string" && [
    "paragraph",
    "bulleted_list_item",
    "numbered_list_item",
    "quote",
    "heading_1",
    "heading_2",
    "heading_3"
  ].includes(value);
  function validOperation(operation, args) {
    switch (operation) {
      case "createPage":
      case "writeMarkdown":
      case "setCaption":
        return args.length === 2 && isId(args[0]) && isText(args[1]);
      case "children":
      case "removeBlock":
        return args.length === 1 && isId(args[0]);
      case "clearMarker":
        return args.length === 2 && isId(args[0]) && isBlockType(args[1]);
      case "writeImageError":
        return args.length === 3 && isId(args[0]) && isBlockType(args[1]) && isText(args[2]);
      case "appendImage": {
        const value = args[0];
        return args.length === 1 && Boolean(value) && isId(value.targetId) && isId(value.markerId) && isId(value.uploadId) && isText(value.marker) && (value.container === void 0 || typeof value.container === "boolean");
      }
      case "uploadImage": {
        const value = args[0];
        return args.length === 1 && Boolean(value) && isText(value.url) && isText(value.type) && Array.isArray(value.bytes) && value.bytes.length > 0 && value.bytes.length <= IMAGE_LIMITS.imageBytes && value.bytes.every((byte) => Number.isInteger(byte) && byte >= 0 && byte <= 255);
      }
      default:
        return false;
    }
  }
  function createNotionHandler({
    repository: repository2,
    runtime,
    fetcher,
    sleep
  }) {
    async function execute(message, sender) {
      const { integrationId, operation, args } = message;
      if (sender.id !== runtime.id || sender.url?.split(/[?#]/)[0] !== runtime.getURL("side-panel.html") || typeof integrationId !== "string" || !integrationId || !Array.isArray(args) || !validOperation(operation, args)) {
        throw failure("notionSettingsError");
      }
      await repository2.initialize();
      const { token } = await repository2.connection(integrationId);
      if (!token) {
        throw failure("notionMissingToken");
      }
      const api = createNotionApi({ token, fetcher, sleep });
      const result = await api[operation](...args);
      if (operation === "createPage") {
        const id = result?.id;
        if (!isId(id)) {
          throw failure("notionSaveError", { ambiguous: true });
        }
        return { id };
      }
      if (operation === "children" || operation === "uploadImage" || operation === "appendImage") {
        return result;
      }
    }
    return function onMessage(message, sender, respond) {
      if (!message || typeof message !== "object" || message.channel !== NOTION_CHANNEL) {
        return;
      }
      const command = message;
      void execute(command, sender).then(
        (value) => respond({ ok: true, value }),
        (caught) => {
          const error = errorDetails(caught);
          const code = notionErrorCodes.find((known) => known === error.code) ?? "notionSaveError";
          respond({
            ok: false,
            code,
            status: typeof error.status === "number" ? error.status : void 0,
            ambiguous: typeof error.ambiguous === "boolean" ? error.ambiguous : code === "notionSaveError" && command.operation !== "children",
            imageReason: error.imageReason === "format" ? "format" : void 0
          });
        }
      );
      return true;
    };
  }

  // extension/queue/repository.ts
  var errorCodes = [
    "queueStorageError",
    "queueInvalidTask",
    "queueTaskNotFound",
    "queueTaskRunning",
    "queueStaleAttempt",
    "queueTaskNotRetryable",
    "queueTaskNotWaiting"
  ];
  var safeError = (error) => {
    const code = errorDetails(error).code;
    return failure(code && errorCodes.includes(code) ? code : "queueStorageError");
  };
  var read = (request) => new Promise((resolve, reject) => {
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
  function copySnapshot(snapshot) {
    const { article, options } = snapshot;
    return {
      article: {
        title: article.title,
        content: article.content,
        url: article.url,
        baseUrl: article.baseUrl,
        characters: article.characters
      },
      title: snapshot.title,
      tabId: snapshot.tabId,
      documentId: snapshot.documentId,
      locale: snapshot.locale,
      options: { sourceLabel: options.sourceLabel }
    };
  }
  function copyUpdate({ status, progress, result, error }) {
    return {
      status,
      progress: progress && {
        stage: progress.stage,
        completed: progress.completed,
        total: progress.total
      },
      result: result && {
        failedCount: result.failedCount,
        pageId: result.pageId,
        downloadId: result.downloadId
      },
      error: error && { code: error.code, retryable: error.retryable }
    };
  }
  function createTaskRepository({
    factory = indexedDB,
    databaseName = "html2md-export-queue",
    createId = () => crypto.randomUUID(),
    now = Date.now
  } = {}) {
    let opening;
    function open() {
      opening ??= new Promise((resolve, reject) => {
        const request = factory.open(databaseName, 1);
        let rejected = false;
        const fail = () => {
          rejected = true;
          opening = void 0;
          reject(failure("queueStorageError"));
        };
        request.onupgradeneeded = () => {
          const db = request.result;
          db.createObjectStore("tasks", { keyPath: "id" }).createIndex("order", "order", {
            unique: true
          });
          db.createObjectStore("payloads");
          db.createObjectStore("commands");
          db.createObjectStore("meta");
        };
        request.onerror = request.onblocked = fail;
        request.onsuccess = () => {
          const db = request.result;
          if (rejected) {
            db.close();
            return;
          }
          db.onversionchange = () => {
            db.close();
            opening = void 0;
          };
          resolve(db);
        };
      }).catch((error) => {
        opening = void 0;
        throw safeError(error);
      });
      return opening;
    }
    async function transaction(stores, mode, action) {
      const db = await open();
      return new Promise((resolve, reject) => {
        let tx;
        try {
          tx = db.transaction(stores, mode, { durability: "strict" });
        } catch (error) {
          reject(safeError(error));
          return;
        }
        let value;
        let caught;
        tx.oncomplete = () => resolve(value);
        tx.onabort = () => reject(safeError(caught));
        void action(tx).then(
          (result) => {
            value = result;
          },
          (error) => {
            caught = error;
            try {
              tx.abort();
            } catch {
              reject(safeError(error));
            }
          }
        );
      });
    }
    async function getTask(tx, id) {
      const task = await read(tx.objectStore("tasks").get(id));
      if (!task) {
        throw failure("queueTaskNotFound");
      }
      return task;
    }
    async function activeTask(tx, id, attemptId) {
      const task = await getTask(tx, id);
      if (task.status !== "running" || !attemptId || task.attemptId !== attemptId) {
        throw failure("queueStaleAttempt");
      }
      return task;
    }
    async function nextOrder(tx) {
      const meta = tx.objectStore("meta");
      const order = (await read(meta.get("order")) ?? 0) + 1;
      meta.put(order, "order");
      return order;
    }
    return {
      async enqueue(input) {
        const { commandId } = input;
        if (!input.commandId || !["archive", "notion"].includes(input.type) || input.type === "notion" && (!input.integration?.id || !input.integration.parentId)) {
          throw failure("queueInvalidTask");
        }
        const snapshot = copySnapshot(input.snapshot);
        const destination = input.type === "notion" ? {
          type: "notion",
          integration: {
            id: input.integration.id,
            name: input.integration.name,
            parentId: input.integration.parentId
          }
        } : { type: "archive" };
        return transaction(["tasks", "payloads", "commands", "meta"], "readwrite", async (tx) => {
          const commands = tx.objectStore("commands");
          const existing = await read(commands.get(commandId));
          if (existing) {
            return existing;
          }
          const timestamp = now();
          const task = {
            ...destination,
            id: createId(),
            title: snapshot.title,
            status: "queued",
            order: await nextOrder(tx),
            createdAt: timestamp,
            updatedAt: timestamp
          };
          tx.objectStore("tasks").add(task);
          tx.objectStore("payloads").add({ snapshot }, task.id);
          commands.add(task.id, commandId);
          return task.id;
        });
      },
      list: () => transaction(
        ["tasks"],
        "readonly",
        (tx) => read(tx.objectStore("tasks").index("order").getAll())
      ),
      get: (id) => transaction(["tasks"], "readonly", (tx) => getTask(tx, id)),
      loadPayload: (id) => transaction(["tasks", "payloads"], "readonly", async (tx) => {
        await getTask(tx, id);
        return read(tx.objectStore("payloads").get(id));
      }),
      claimNext: () => transaction(["tasks"], "readwrite", async (tx) => {
        const tasks2 = await read(tx.objectStore("tasks").index("order").getAll());
        if (tasks2.some((task2) => task2.status === "running")) {
          return;
        }
        const task = tasks2.find((task2) => task2.status === "queued");
        if (!task) {
          return;
        }
        task.status = "running";
        task.attemptId = createId();
        task.updatedAt = now();
        tx.objectStore("tasks").put(task);
        return task;
      }),
      // The scheduler holds a cross-context Web Lock before recovering a stopped executor.
      recover: (id, attemptId) => transaction(["tasks"], "readwrite", async (tx) => {
        const task = await activeTask(tx, id, attemptId);
        task.status = "queued";
        task.updatedAt = now();
        delete task.attemptId;
        tx.objectStore("tasks").put(task);
      }),
      waitForCredentials: (id) => transaction(["tasks"], "readwrite", async (tx) => {
        const task = await getTask(tx, id);
        if (task.status !== "queued") {
          return;
        }
        task.status = "waiting_credentials";
        task.updatedAt = now();
        task.error = { code: "notionMissingToken", retryable: false };
        tx.objectStore("tasks").put(task);
      }),
      update: (id, attemptId, update) => {
        const patch = copyUpdate(update);
        return transaction(["tasks", "payloads"], "readwrite", async (tx) => {
          const task = await activeTask(tx, id, attemptId);
          for (const [key, value] of Object.entries(patch)) {
            if (value !== void 0) {
              Object.assign(task, { [key]: value });
            }
          }
          task.updatedAt = now();
          if (task.status === "completed") {
            delete task.error;
            const payload = await read(tx.objectStore("payloads").get(id));
            delete payload.checkpoint;
            tx.objectStore("payloads").put(payload, id);
          }
          tx.objectStore("tasks").put(task);
        });
      },
      saveCheckpoint: async (id, attemptId, checkpoint) => {
        let saved;
        try {
          saved = structuredClone(checkpoint);
        } catch (error) {
          throw safeError(error);
        }
        return transaction(["tasks", "payloads"], "readwrite", async (tx) => {
          const task = await activeTask(tx, id, attemptId);
          if (saved.type !== task.type) {
            throw failure("queueInvalidTask");
          }
          const payload = await read(tx.objectStore("payloads").get(id));
          payload.checkpoint = saved;
          tx.objectStore("payloads").put(payload, id);
        });
      },
      retry: (id) => transaction(["tasks", "meta", "payloads"], "readwrite", async (tx) => {
        const task = await getTask(tx, id);
        if (task.status !== "failed" || !task.error?.retryable) {
          throw failure("queueTaskNotRetryable");
        }
        task.status = "queued";
        task.order = await nextOrder(tx);
        task.updatedAt = now();
        delete task.error;
        delete task.progress;
        delete task.attemptId;
        const payload = await read(tx.objectStore("payloads").get(id));
        if (payload.checkpoint?.type === "archive") {
          delete payload.checkpoint.download;
          tx.objectStore("payloads").put(payload, id);
        }
        tx.objectStore("tasks").put(task);
      }),
      resume: (id) => transaction(["tasks"], "readwrite", async (tx) => {
        const task = await getTask(tx, id);
        if (task.status !== "waiting_credentials") {
          throw failure("queueTaskNotWaiting");
        }
        task.status = "queued";
        task.updatedAt = now();
        delete task.error;
        delete task.attemptId;
        tx.objectStore("tasks").put(task);
      }),
      remove: (id) => transaction(["tasks", "payloads"], "readwrite", async (tx) => {
        const task = await getTask(tx, id);
        if (task.status === "running") {
          throw failure("queueTaskRunning");
        }
        tx.objectStore("tasks").delete(id);
        tx.objectStore("payloads").delete(id);
      }),
      clearCompleted: () => transaction(["tasks", "payloads"], "readwrite", async (tx) => {
        const tasks2 = tx.objectStore("tasks");
        for (const task of await read(tasks2.getAll())) {
          if (task.status === "completed") {
            tasks2.delete(task.id);
            tx.objectStore("payloads").delete(task.id);
          }
        }
      }),
      async close() {
        if (opening) {
          (await opening).close();
          opening = void 0;
        }
      }
    };
  }

  // extension/queue/commands.ts
  var QUEUE_CHANNEL = "html2md-queue";
  var queueErrorCodes = [
    "queueStorageError",
    "queueInvalidTask",
    "queueTaskNotFound",
    "queueTaskRunning",
    "queueStaleAttempt",
    "queueTaskNotRetryable",
    "queueTaskNotWaiting",
    "queueNeedsReview",
    "integrationNotFound",
    "notionMissingToken",
    "notionSettingsError"
  ];

  // extension/background/queue-handler.ts
  function validInput2(value) {
    const input = value;
    const snapshot = input?.snapshot;
    return Boolean(
      input && ["archive", "notion"].includes(input.type) && typeof input.commandId === "string" && input.commandId && snapshot && typeof snapshot.title === "string" && Number.isInteger(snapshot.tabId) && snapshot.tabId >= 0 && typeof snapshot.documentId === "string" && snapshot.documentId && ["en", "ru"].includes(snapshot.locale) && snapshot.options && typeof snapshot.options.sourceLabel === "string" && snapshot.article && ["title", "content", "url", "baseUrl"].every(
        (key) => typeof snapshot.article[key] === "string"
      ) && (input.type !== "notion" || typeof input.integrationId === "string")
    );
  }
  function createQueueHandler({
    tasks: tasks2,
    integrations,
    runtime,
    wake: wake2,
    publish: publish2
  }) {
    async function execute(message, sender) {
      const url = sender.url?.split(/[?#]/)[0];
      if (sender.id !== runtime.id) {
        throw failure("queueInvalidTask");
      }
      if (url === runtime.getURL("offscreen.html") && message.type === "wake") {
        wake2();
        return;
      }
      if (url !== runtime.getURL("side-panel.html")) {
        throw failure("queueInvalidTask");
      }
      if (message.type === "list") {
        return tasks2.list();
      }
      if (message.type === "enqueue") {
        if (!validInput2(message.input)) {
          throw failure("queueInvalidTask");
        }
        const input = message.input;
        if (input.type === "notion") {
          await integrations.initialize();
        }
        const destination = input.type === "notion" ? (await integrations.list()).find((item) => item.id === input.integrationId) : void 0;
        if (input.type === "notion" && !destination) {
          throw failure("integrationNotFound");
        }
        const id = await tasks2.enqueue(
          input.type === "archive" ? { type: "archive", commandId: input.commandId, snapshot: input.snapshot } : {
            type: "notion",
            commandId: input.commandId,
            snapshot: input.snapshot,
            integration: {
              id: destination.id,
              name: destination.name,
              parentId: destination.parentId
            }
          }
        );
        wake2();
        await publish2();
        return id;
      }
      if (message.type === "clear") {
        await tasks2.clearCompleted();
      } else if (typeof message.id === "string" && message.type === "retry") {
        await tasks2.retry(message.id);
        wake2();
      } else if (typeof message.id === "string" && message.type === "remove") {
        await tasks2.remove(message.id);
      } else {
        throw failure("queueInvalidTask");
      }
      await publish2();
    }
    return (message, sender, respond) => {
      if (!message || typeof message !== "object" || message.channel !== QUEUE_CHANNEL) {
        return;
      }
      void execute(message, sender).then(
        (value) => respond({ ok: true, value }),
        (caught) => {
          const code = errorDetails(caught).code;
          respond({
            ok: false,
            code: queueErrorCodes.find((known) => known === code) ?? "queueStorageError"
          });
        }
      );
      return true;
    };
  }

  // extension/shared/messages.ts
  var reasons = {
    http: "imageHttp",
    network: "imageNetwork",
    tabAccess: "imageTabAccess",
    timeout: "imageTimeout",
    format: "imageFormat",
    size: "imageSize",
    totalSize: "imageTotalSize",
    empty: "imageEmpty",
    location: "imageLocation",
    upload: "imageUpload"
  };
  function createMessageFormatter(t) {
    return {
      imageError: ({ reason, status }) => t("notionImageError", t(reasons[reason] ?? "imageUpload", String(status ?? ""))),
      progress: ({ stage, completed, total }) => t(
        {
          download: "notionDownloadingImages",
          upload: "notionUploadingImages",
          finish: "notionFinishingImages"
        }[stage],
        [String(completed), String(total)]
      ),
      error: (caught, fallback = "notionSaveError") => {
        const error = errorDetails(caught);
        return t(
          [
            "notionUnauthorized",
            "notionForbidden",
            "notionNotFound",
            "notionRateLimited",
            "notionSaveError",
            "notionSettingsError",
            "notionInvalidParent",
            "notionMissingToken",
            "integrationNameRequired",
            "integrationNotFound",
            "notionImageUncertain",
            "queueStorageError",
            "queueInvalidTask",
            "queueTaskRunning",
            "queueTaskNotRetryable"
          ].includes(error.code ?? error.message ?? "") ? error.code ?? error.message : fallback
        );
      }
    };
  }

  // extension/background/executor.ts
  function createExportExecutor(options) {
    const { tasks: tasks2, offscreen: offscreen2, downloads, publish: publish2 } = options;
    let running;
    let requested = false;
    async function release(id) {
      await offscreen2({ type: "release", taskId: id }).catch(() => {
      });
    }
    async function reconcile(task, checkpoint) {
      const download = checkpoint.download;
      if (download.id === void 0) {
        const matches = await downloads.search({ url: download.url });
        if (matches.length === 1) {
          download.id = matches[0].id;
          download.phase = "started";
          await tasks2.saveCheckpoint(task.id, task.attemptId, checkpoint);
        }
      }
      const [item] = download.id === void 0 ? [] : await downloads.search({ id: download.id });
      if (item?.state === "in_progress") {
        return;
      }
      const status = item?.state === "complete" ? "completed" : item?.state === "interrupted" ? "failed" : "needs_review";
      await tasks2.update(task.id, task.attemptId, {
        status,
        result: { failedCount: checkpoint.archive?.failedCount ?? 0, downloadId: download.id },
        error: {
          code: status === "needs_review" ? "queueNeedsReview" : "downloadError",
          retryable: status === "failed"
        }
      });
      if (status !== "needs_review") {
        await release(task.id);
      }
    }
    async function execute(task) {
      const attemptId = task.attemptId;
      const { snapshot } = await tasks2.loadPayload(task.id);
      let state;
      let progress = { stage: "prepare", completed: 0, total: 0 };
      const saveProgress = async (count, total) => {
        progress = { stage: "download", completed: count, total };
        await tasks2.update(task.id, attemptId, { progress });
        await publish2();
      };
      try {
        await offscreen2({ type: "activity", active: true });
        await tasks2.update(task.id, attemptId, { progress });
        await publish2();
        if (task.type === "notion") {
          await offscreen2({ type: "prepare", taskId: task.id, attemptId });
          const checkpoint = (await tasks2.loadPayload(task.id)).checkpoint;
          if (checkpoint?.type !== "notion") {
            throw failure("queueStorageError");
          }
          state = checkpoint.state;
          const checkpointState = async () => {
            await tasks2.saveCheckpoint(task.id, attemptId, { type: "notion", state });
            await tasks2.update(task.id, attemptId, {
              progress,
              result: { pageId: state.page?.id, failedCount: state.failedCount }
            });
            await publish2();
          };
          const formatImageError = createMessageFormatter(
            await options.translate(snapshot.locale)
          ).imageError;
          const exportArticle = () => exportNotionArticle({
            state,
            api: options.api(task.integration.id),
            parentId: task.integration.parentId,
            title: task.title,
            formatImageError,
            checkpoint: checkpointState,
            progress: (event) => {
              progress = event;
            },
            downloadImages: (urls) => options.images(snapshot, urls, (count) => saveProgress(count, urls.length))
          });
          try {
            await exportArticle();
          } catch (error) {
            if (!errorDetails(error).ambiguous || !state.page) {
              throw error;
            }
            await exportArticle();
          }
          await tasks2.update(task.id, attemptId, {
            status: "completed",
            result: { pageId: state.page.id, failedCount: state.failedCount }
          });
        } else {
          let checkpoint = (await tasks2.loadPayload(task.id)).checkpoint;
          if (checkpoint?.type !== "archive") {
            checkpoint = { type: "archive" };
          }
          if (!checkpoint.images) {
            const urls = await offscreen2({
              type: "image-urls",
              taskId: task.id,
              attemptId
            });
            checkpoint.images = await options.images(
              snapshot,
              urls,
              (count) => saveProgress(count, urls.length)
            );
            await tasks2.saveCheckpoint(task.id, attemptId, checkpoint);
          }
          await offscreen2({ type: "prepare", taskId: task.id, attemptId });
          checkpoint = (await tasks2.loadPayload(task.id)).checkpoint;
          if (checkpoint?.type !== "archive" || !checkpoint.archive) {
            throw failure("queueStorageError");
          }
          const url = await offscreen2({ type: "archive-url", taskId: task.id, attemptId });
          checkpoint.download = { phase: "starting", url };
          await tasks2.saveCheckpoint(task.id, attemptId, checkpoint);
          await tasks2.update(task.id, attemptId, {
            progress: { stage: "save", completed: 0, total: 0 }
          });
          let id;
          try {
            id = await downloads.download({
              url,
              filename: checkpoint.archive.filename,
              conflictAction: "uniquify"
            });
          } catch {
            throw failure("queueNeedsReview", { ambiguous: true });
          }
          checkpoint.download = { phase: "started", url, id };
          await tasks2.saveCheckpoint(task.id, attemptId, checkpoint);
          await reconcile(task, checkpoint);
        }
      } catch (caught) {
        const error = errorDetails(caught);
        if (error.code === "queueStaleAttempt") {
          return;
        }
        const saved = task.type === "archive" ? (await tasks2.loadPayload(task.id)).checkpoint : void 0;
        if (saved?.type === "archive" && saved.download?.id !== void 0) {
          throw caught;
        }
        const uncertain = error.ambiguous || ["notionImageUncertain", "queueNeedsReview"].includes(error.code ?? "") || saved?.type === "archive" && Boolean(saved.download) || error.code === "queueStorageError" && (Boolean(state?.page) || state?.creation === "uncertain" || state?.writing === "uncertain");
        const waiting = ["notionMissingToken", "integrationNotFound", "notionUnauthorized"].includes(
          error.code ?? ""
        );
        await tasks2.update(task.id, attemptId, {
          status: waiting ? "waiting_credentials" : uncertain ? "needs_review" : "failed",
          error: {
            code: uncertain ? "queueNeedsReview" : error.code ?? "notionSaveError",
            retryable: !uncertain && !waiting
          },
          result: state?.page ? { pageId: state.page.id, failedCount: state.failedCount } : void 0
        });
        if (!uncertain) {
          await release(task.id);
        }
      } finally {
        await offscreen2({ type: "activity", active: false }).catch(() => {
        });
        await publish2();
      }
    }
    async function connected(task) {
      if (task.type === "archive") {
        return true;
      }
      try {
        return await options.connected(task.integration.id);
      } catch {
        return false;
      }
    }
    async function drain() {
      for (const task of await tasks2.list()) {
        if (task.status === "running") {
          const checkpoint = (await tasks2.loadPayload(task.id)).checkpoint;
          if (checkpoint?.type === "archive" && checkpoint.download) {
            await reconcile(task, checkpoint);
          } else {
            await tasks2.recover(task.id, task.attemptId);
          }
        }
      }
      for (const task of await tasks2.list()) {
        if (task.status === "waiting_credentials" && task.error?.code !== "notionUnauthorized" && await connected(task)) {
          await tasks2.resume(task.id);
        }
        if (task.status === "queued" && !await connected(task)) {
          await tasks2.waitForCredentials(task.id);
        }
      }
      for (; ; ) {
        const task = await tasks2.claimNext();
        if (!task) {
          break;
        }
        if (!await connected(task)) {
          await tasks2.update(task.id, task.attemptId, {
            status: "waiting_credentials",
            error: { code: "notionMissingToken", retryable: false }
          });
          continue;
        }
        await execute(task);
        if ((await tasks2.get(task.id)).status === "running") {
          break;
        }
      }
      await publish2();
      await offscreen2({ type: "activity", active: false }).catch(() => {
      });
    }
    return {
      run() {
        if (running) {
          requested = true;
          return running;
        }
        requested = false;
        running = options.exclusive(async () => {
          do {
            requested = false;
            await drain();
          } while (requested);
        }).finally(() => {
          running = void 0;
        });
        return running;
      },
      async credentialsChanged(integrationId) {
        for (const task of await tasks2.list()) {
          if (task.type === "notion" && task.integration.id === integrationId && task.status === "waiting_credentials") {
            await tasks2.resume(task.id);
          }
        }
      }
    };
  }

  // extension/background/offscreen.ts
  function createOffscreenBridge(host) {
    let creating;
    return async function request(message) {
      const contexts = await host.runtime.getContexts({
        contextTypes: [host.runtime.ContextType.OFFSCREEN_DOCUMENT]
      });
      if (!contexts.length && (message.type === "release" || message.type === "activity" && !message.active)) {
        return void 0;
      }
      if (!contexts.length) {
        creating ??= host.offscreen.createDocument({
          url: "offscreen.html",
          reasons: [host.offscreen.Reason.DOM_PARSER, host.offscreen.Reason.BLOBS],
          justification: "Prepare saved article exports and retain ZIP blob URLs until Chrome finishes downloading."
        });
        try {
          await creating;
        } finally {
          creating = void 0;
        }
      }
      const response = await host.runtime.sendMessage({ channel: "html2md-offscreen", ...message });
      if (!response?.ok) {
        throw failure("queueStorageError");
      }
      return response.value;
    };
  }

  // extension/background/task-api.ts
  function createTaskApi(repository2, integrationId, fetcher, sleep) {
    async function invoke(operation, args) {
      const { token } = await repository2.connection(integrationId);
      if (!token) {
        throw failure("notionMissingToken");
      }
      const api = createNotionApi({ token, fetcher, sleep });
      try {
        return await api[operation](...args);
      } catch (error) {
        if (errorDetails(error).status === 401) {
          const current = await repository2.connection(integrationId);
          if (current.token && current.token !== token) {
            throw failure("notionMissingToken");
          }
        }
        throw error;
      }
    }
    return {
      createPage: (...args) => invoke("createPage", args),
      writeMarkdown: (...args) => invoke("writeMarkdown", args),
      children: (...args) => invoke("children", args),
      uploadImage: (...args) => invoke("uploadImage", args),
      appendImage: (...args) => invoke("appendImage", args),
      setCaption: (...args) => invoke("setCaption", args),
      clearMarker: (...args) => invoke("clearMarker", args),
      removeBlock: (...args) => invoke("removeBlock", args),
      writeImageError: (...args) => invoke("writeImageError", args)
    };
  }

  // extension/shared/task-localization.ts
  function createTaskTranslator(getURL, fetcher) {
    const catalogs = /* @__PURE__ */ new Map();
    return async (locale) => {
      if (!catalogs.has(locale)) {
        const loading = fetcher(getURL(`_locales/${locale}/messages.json`)).then((response) => {
          if (!response.ok) {
            throw new Error("Could not load task translations");
          }
          return response.json();
        }).catch((error) => {
          catalogs.delete(locale);
          throw error;
        });
        catalogs.set(locale, loading);
      }
      const catalog = await catalogs.get(locale);
      return (key, substitutions) => {
        const entry = catalog[key];
        const values = Array.isArray(substitutions) ? substitutions : [substitutions ?? ""];
        return (entry?.message ?? key).replace(
          /\$([A-Z]+)\$/g,
          (_, name) => values[Number(entry?.placeholders?.[name.toLowerCase()]?.content.slice(1)) - 1] ?? ""
        );
      };
    };
  }

  // extension/browser/image-function.ts
  function fetchImagesInPage(urls, maxTotalBytes) {
    var html2mdPageImages = (() => {
      var __defProp2 = Object.defineProperty;
      var __getOwnPropDesc2 = Object.getOwnPropertyDescriptor;
      var __getOwnPropNames2 = Object.getOwnPropertyNames;
      var __hasOwnProp2 = Object.prototype.hasOwnProperty;
      var __export = (target, all) => {
        for (var name in all)
          __defProp2(target, name, { get: all[name], enumerable: true });
      };
      var __copyProps2 = (to, from, except, desc) => {
        if (from && typeof from === "object" || typeof from === "function") {
          for (let key of __getOwnPropNames2(from))
            if (!__hasOwnProp2.call(to, key) && key !== except)
              __defProp2(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc2(from, key)) || desc.enumerable });
        }
        return to;
      };
      var __toCommonJS = (mod) => __copyProps2(__defProp2({}, "__esModule", { value: true }), mod);
      var image_function_exports = {};
      __export(image_function_exports, {
        fetchImagesInPage: () => fetchImagesInPage2
      });
      function errorDetails2(value) {
        return typeof value === "object" && value !== null ? value : {};
      }
      var IMAGE_LIMITS2 = Object.freeze({
        imageBytes: 10 * 1024 * 1024,
        totalBytes: 50 * 1024 * 1024,
        timeoutMs: 1e4
      });
      async function fetchImages2(urls2, {
        fetcher,
        maxTotalBytes: maxTotalBytes2 = IMAGE_LIMITS2.totalBytes,
        credentials = "same-origin",
        fallback,
        progress = () => {
        }
      }) {
        const results = [];
        let totalBytes = 0;
        progress({ stage: "download", completed: 0, total: urls2.length });
        for (const url of urls2) {
          let size = 0;
          try {
            if (totalBytes >= maxTotalBytes2) {
              throw Object.assign(new Error(), { reason: "totalSize" });
            }
            const response = await fetcher(url, {
              credentials,
              signal: AbortSignal.timeout(IMAGE_LIMITS2.timeoutMs)
            });
            const type = response.headers.get("content-type")?.split(";")[0].trim().toLowerCase();
            if (!response.ok) {
              throw Object.assign(new Error(), { reason: "http", status: response.status });
            }
            if (!type?.startsWith("image/")) {
              throw Object.assign(new Error(), { reason: "format" });
            }
            const reader = response.body.getReader();
            const chunks = [];
            while (true) {
              const { done, value } = await reader.read();
              if (done) {
                break;
              }
              size += value.length;
              totalBytes += value.length;
              if (size > IMAGE_LIMITS2.imageBytes || totalBytes > maxTotalBytes2) {
                await reader.cancel();
                throw Object.assign(new Error(), {
                  reason: size > IMAGE_LIMITS2.imageBytes ? "size" : "totalSize"
                });
              }
              chunks.push(value);
            }
            if (!size) {
              throw Object.assign(new Error(), { reason: "empty" });
            }
            const bytes = new Uint8Array(size);
            let offset = 0;
            for (const chunk of chunks) {
              bytes.set(chunk, offset);
              offset += chunk.length;
            }
            results.push({ url, type, bytes: Array.from(bytes), transferredBytes: size });
          } catch (caught) {
            const error = errorDetails2(caught);
            let recovered = false;
            if (fallback && !["size", "totalSize"].includes(error.reason ?? "")) {
              try {
                const image = await fallback(url);
                if (image?.bytes?.length) {
                  size += image.bytes.length;
                  totalBytes += image.bytes.length;
                  if (image.bytes.length > IMAGE_LIMITS2.imageBytes || totalBytes > maxTotalBytes2) {
                    error.reason = image.bytes.length > IMAGE_LIMITS2.imageBytes ? "size" : "totalSize";
                  } else {
                    results.push({ ...image, url, transferredBytes: size });
                    recovered = true;
                  }
                }
              } catch {
              }
            }
            if (!recovered) {
              results.push({
                url,
                failed: true,
                reason: error.reason ?? (["TimeoutError", "AbortError"].includes(error.name ?? "") ? "timeout" : "network"),
                status: error.status,
                transferredBytes: size
              });
            }
          }
          progress({ stage: "download", completed: results.length, total: urls2.length });
        }
        return results;
      }
      async function canvasImage(url, document2) {
        const image = [...document2.images].find(
          (image2) => (image2.currentSrc || image2.src) === url && image2.complete && image2.naturalWidth > 0
        );
        if (!image || image.naturalWidth * image.naturalHeight > 16 * 1024 * 1024) {
          return;
        }
        const canvas = document2.createElement("canvas");
        canvas.width = image.naturalWidth;
        canvas.height = image.naturalHeight;
        canvas.getContext("2d").drawImage(image, 0, 0);
        const blob = await new Promise((resolve) => canvas.toBlob(resolve, "image/png"));
        if (blob) {
          return { type: "image/png", bytes: Array.from(new Uint8Array(await blob.arrayBuffer())) };
        }
      }
      function fetchPageImages(urls2, maxTotalBytes2, { document: document2, fetcher }) {
        return fetchImages2(urls2, {
          fetcher,
          maxTotalBytes: maxTotalBytes2,
          credentials: "include",
          fallback: (url) => canvasImage(url, document2)
        });
      }
      function fetchImagesInPage2(urls2, maxTotalBytes2) {
        return fetchPageImages(urls2, maxTotalBytes2, { document, fetcher: fetch });
      }
      return __toCommonJS(image_function_exports);
    })();
    return html2mdPageImages.fetchImagesInPage(urls, maxTotalBytes);
  }

  // extension/browser/download-images.ts
  async function downloadPageImages(scripting, tabId, urls, progress = () => {
  }, documentId) {
    const results = [];
    let remaining = IMAGE_LIMITS.totalBytes;
    await progress(0);
    for (const url of urls) {
      let image;
      try {
        const [{ result } = {}] = await scripting.executeScript({
          target: { tabId, ...documentId ? { documentIds: [documentId] } : {} },
          world: "MAIN",
          func: fetchImagesInPage,
          args: [[url], remaining]
        });
        image = result?.find((item) => item.url === url);
      } catch {
      }
      image ??= { url, failed: true, reason: "tabAccess" };
      remaining = Math.max(0, remaining - (image.transferredBytes ?? image.bytes?.length ?? 0));
      results.push(image);
      await progress(results.length);
    }
    return results;
  }

  // extension/background/panel.ts
  function registerSidePanel(host) {
    void host.sidePanel.setPanelBehavior({ openPanelOnActionClick: false }).catch((error) => {
      console.error("Could not configure the side panel.", error);
    });
    async function openPanel(windowId) {
      try {
        await host.sidePanel.open({ windowId });
      } catch (error) {
        console.error("Could not open the side panel.", error);
        return;
      }
      try {
        await host.runtime.sendMessage({ channel: "html2md-source-access", windowId });
      } catch (error) {
        if (!String(error).includes("Receiving end does not exist")) {
          console.error("Could not refresh side panel access.", error);
        }
      }
    }
    host.action.onClicked.addListener((tab) => {
      void openPanel(tab.windowId);
    });
  }

  // extension/background/main.ts
  registerSidePanel(chrome);
  var tasks = createTaskRepository();
  var offscreen = createOffscreenBridge(chrome);
  var repository = createIntegrationRepository({
    storage: chrome.storage,
    locks: navigator.locks,
    createId: () => crypto.randomUUID()
  });
  var publishing = Promise.resolve();
  function publish() {
    publishing = publishing.catch(() => {
    }).then(async () => {
      const snapshot = await tasks.list();
      await chrome.runtime.sendMessage({ channel: "html2md-queue-update", tasks: snapshot }).catch(() => {
      });
    });
    return publishing;
  }
  var executor = createExportExecutor({
    tasks,
    offscreen,
    publish,
    downloads: chrome.downloads,
    translate: createTaskTranslator(chrome.runtime.getURL, fetch),
    connected: async (id) => {
      await repository.initialize();
      return Boolean((await repository.connection(id)).token);
    },
    api: (id) => createTaskApi(
      repository,
      id,
      fetch,
      (ms) => new Promise((resolve) => setTimeout(resolve, ms))
    ),
    images: (snapshot, urls, progress) => downloadPageImages(chrome.scripting, snapshot.tabId, urls, progress, snapshot.documentId),
    exclusive: (action) => navigator.locks.request("html2md-export-executor", { ifAvailable: true }, async (lock) => {
      if (lock) {
        await action();
      }
    })
  });
  var wake = () => {
    void executor.run().catch(() => {
      console.error("Could not process the export queue.");
    });
  };
  chrome.runtime.onMessage.addListener(
    createQueueHandler({ tasks, integrations: repository, runtime: chrome.runtime, wake, publish })
  );
  chrome.alarms.onAlarm.addListener((alarm) => {
    if (alarm.name === "html2md-queue") {
      wake();
    }
  });
  chrome.downloads.onChanged.addListener(wake);
  chrome.runtime.onStartup.addListener(wake);
  chrome.runtime.onInstalled.addListener(wake);
  chrome.storage.onChanged.addListener((changes) => {
    for (const [key, change] of Object.entries(changes)) {
      if (key.startsWith("integrationToken:") && change.newValue) {
        void executor.credentialsChanged(key.slice("integrationToken:".length)).then(wake).catch(() => {
        });
      }
    }
    if (changes.integrations) {
      wake();
    }
  });
  void chrome.alarms.create("html2md-queue", { periodInMinutes: 0.5 });
  wake();
  chrome.runtime.onMessage.addListener(createIntegrationHandler(repository, chrome.runtime));
  chrome.runtime.onMessage.addListener(
    createNotionHandler({
      repository,
      runtime: chrome.runtime,
      fetcher: fetch,
      sleep: (ms) => new Promise((resolve) => setTimeout(resolve, ms))
    })
  );
  function restrictStorageAccess() {
    void Promise.all([
      chrome.storage.local.setAccessLevel({ accessLevel: "TRUSTED_CONTEXTS" }),
      chrome.storage.session.setAccessLevel({ accessLevel: "TRUSTED_CONTEXTS" })
    ]).catch(() => {
      console.error("Could not restrict extension storage access.");
    });
  }
  chrome.runtime.onInstalled.addListener(restrictStorageAccess);
  chrome.runtime.onStartup.addListener(restrictStorageAccess);
  restrictStorageAccess();
})();
